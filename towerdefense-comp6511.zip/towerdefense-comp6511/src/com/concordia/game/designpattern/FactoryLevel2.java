package com.concordia.game.designpattern;

/**
 * 
 * Defines the second level of game and points in the user account after one level.
 * and implement the second level of game with IlevelFactory class.
 *
 */
public class FactoryLevel2 implements ILevelFactory
{
	/**
	 * Method to get the level specification based on the difficulty indulged in particular level
	 * @return levelString String representing level difficulty
	 */
	@Override
	public String getSpecification() 
	{		
		String levelString = "Intermediate";
		return levelString; // return the second level in levelString.
	}
	/**
	 * Method to get the coinage set for a particular level based on the difficulty to be indulged in a particular level
	 * @return coinage the value of coinage for a particular level
	 */
	@Override
	public int getCoinage()
	{
		int coinage = 40;
		return coinage;//return the coins in the user account after first level.
	}
}
