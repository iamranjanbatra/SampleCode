package com.concordia.game.designpattern;

public abstract class GameLevelDecorator extends ILevelDecorator
{

	protected  ILevelDecorator gameLevelDecorator;
	
	public GameLevelDecorator(ILevelDecorator gameLevelDecorator)
	{
		this.gameLevelDecorator = gameLevelDecorator;
	}
	public String tipToWin() 
	{
		return gameLevelDecorator.tipToWin();
	}

	public String gameMessage() 
	{	
		return gameLevelDecorator.gameMessage();
	}
}
