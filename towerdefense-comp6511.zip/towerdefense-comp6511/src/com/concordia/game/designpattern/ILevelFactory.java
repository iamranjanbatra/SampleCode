package com.concordia.game.designpattern;
/**
 * 
 * interface the methods to specify the characteristics of various level of game and 
 * call the coinage method to keep the record of points in user account.
 *
 */
public interface ILevelFactory 
{
	public String getSpecification();		//Level difficulty specifications
	public int getCoinage();
}
