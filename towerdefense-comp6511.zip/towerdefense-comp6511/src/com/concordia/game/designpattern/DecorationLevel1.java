package com.concordia.game.designpattern;

public class DecorationLevel1 extends GameLevelDecorator
{

	public DecorationLevel1(ILevelDecorator gameLevelDecorator) 
	{
		super(gameLevelDecorator);
	}
	public String tipToWin()
	{
		return super.tipToWin();
	}
	public String gameMessage()
	{
		return super.gameMessage();
	}
}
