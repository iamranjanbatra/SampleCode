package com.concordia.game.designpattern;

import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.concordia.game.view.GameWindow;
/**
 * 
 * Defines the level of game and initial points in the user account.
 * and implement the First level of game and IlevelFactory class.
 *
 */
public class FactoryLevel1  implements ILevelFactory 
{
	
	/**
	 * Method to get the level specification based on the difficulty indulged in particular level
	 * @return levelString String representing level difficulty
	 */
	@Override
	public String getSpecification() 
	{
		String levelString = "Beginner"; 
		return levelString; // return the first level in levelString.
	}
	
	/**
	 * Method to get the coinage set for a particular level based on the difficulty to be indulged in a particular level
	 * @return coinage the value of coinage for a particular level
	 */
	@Override
	public int getCoinage()
	{
		int coinage = 60;
		return coinage; //return the initial coins in the user account.
	}


}
