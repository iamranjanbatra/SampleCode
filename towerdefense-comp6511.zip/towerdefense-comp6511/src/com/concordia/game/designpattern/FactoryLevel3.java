package com.concordia.game.designpattern;
/**
 * 
 * Defines the third level of game and points in the user account after second level.
 * and implement the third level of game with IlevelFactory class.
 *
 */
public class FactoryLevel3 implements ILevelFactory
{
	/**
	 * Method to get the level specification based on the difficulty indulged in particular level
	 * @return levelString String representing level difficulty
	 */
	@Override
	public String getSpecification() 
	{
		String levelString = "Advanced";
		return levelString;// return the third level in levelString.
	}
	/**
	 * Method to get the coinage set for a particular level based on the difficulty to be indulged in a particular level
	 * @return coinage the value of coinage for a particular level
	 */
	@Override
	public int getCoinage()
	{
		int coinage = 20;
		return coinage; //return the coins in the user account after second level.
	}
	
}
