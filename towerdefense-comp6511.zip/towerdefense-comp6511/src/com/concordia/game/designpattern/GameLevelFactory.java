package com.concordia.game.designpattern;

import com.concordia.game.model.Data;
import com.concordia.game.model.GameBoardTile;
import com.concordia.game.view.GameWindowPanel;
/**
 * 
 * Set the various levels of game starting from Beginner level to advanced level.
 * Also specifies the various characteristics like coinage(point) is user account.
 *
 */
public class GameLevelFactory {
	/**
	 * constructor defines the characteristics for various levels of game.
	 * @param level level of game (beginner, intermediate, advanced)
	 */
	public GameLevelFactory(int level)
	{
		//set level; 
	}
	/**
	 * Method on initialize the level specifications required for game implementation
	 * @param level the particular level on which user is playing
	 */
	public void setLevels(int level)
	{
	if(level == 1)//for beginner level
	{	
		ILevelFactory levelFactory = LevelSpecifications.getLevel("Level 1");
		GameWindowPanel.levelString = levelFactory.getSpecification(); //provide the specifications of level1
		GameWindowPanel.coinage = levelFactory.getCoinage();// get the points in user account
		
		GameLevelStrategy levelReq = new GameLevelStrategy(); //get the characteristics of level 1
		levelReq.setLevelStrategy(new StrategyLevel1()); //call the strategy design pattern for tower shooting
		GameWindowPanel.health =levelReq.executeRequirementStrategy(GameWindowPanel.coinage, 0);		// Health Parameter = 0 
		GameWindowPanel.killsToWin=levelReq.executeRequirementStrategy(GameWindowPanel.coinage, 1);		// Kills to Win Parameter = 1 
		GameWindowPanel.maxMobs=levelReq.executeRequirementStrategy(GameWindowPanel.coinage, 2);		// Mobs to Lose Parameter = 2

		GameBoardTile.tower1RangeOfFire = Data.tower1RangeOfFire + 0; //set range of shooting of tower1.
		GameBoardTile.tower2RangeOfFire = Data.tower2RangeOfFire + 1; //set range of shooting of tower2.
		GameBoardTile.tower3RangeOfFire = Data.tower3RangeOfFire + 2; //set range of shooting of tower3.
	}
	else if(level == 2)
	{
		ILevelFactory levelFactory = LevelSpecifications.getLevel("Level 2");
		GameWindowPanel.levelString = levelFactory.getSpecification();//provide the specifications of level2
		GameWindowPanel.coinage = levelFactory.getCoinage();// get the points in user account
		
		GameLevelStrategy levelReq = new GameLevelStrategy(); //get the requirements of level 2
		levelReq.setLevelStrategy(new StrategyLevel2()); //call the strategy design pattern for tower shooting
		GameWindowPanel.health =levelReq.executeRequirementStrategy(GameWindowPanel.coinage, 0); // Health Parameter = 0 
		GameWindowPanel.killsToWin=levelReq.executeRequirementStrategy(GameWindowPanel.coinage, 1); // Kills to Win Parameter = 1 
		GameWindowPanel.maxMobs=levelReq.executeRequirementStrategy(GameWindowPanel.coinage, 2); // Mobs to Lose Parameter = 2
		
		GameBoardTile.tower1RangeOfFire = Data.tower1RangeOfFire + 0;//set range of shooting of tower1.
		GameBoardTile.tower2RangeOfFire = Data.tower2RangeOfFire + 1; //set range of shooting of tower2.
		GameBoardTile.tower3RangeOfFire = Data.tower3RangeOfFire + 2; //set range of shooting of tower3.
	}
	else if(level == 3)
	{
		ILevelFactory levelFactory = LevelSpecifications.getLevel("Level 3");
		GameWindowPanel.levelString = levelFactory.getSpecification(); //provide the specifications of level3
		GameWindowPanel.coinage = levelFactory.getCoinage();// get the points in user account
		
		GameLevelStrategy levelReq = new GameLevelStrategy();//get the requirements of level 3
		levelReq.setLevelStrategy(new StrategyLevel3()); //call the strategy design pattern for tower shooting
		GameWindowPanel.health =levelReq.executeRequirementStrategy(GameWindowPanel.coinage, 0);// Health Parameter = 0 
		GameWindowPanel.killsToWin=levelReq.executeRequirementStrategy(GameWindowPanel.coinage, 1); // Kills to Win Parameter = 1 
		GameWindowPanel.maxMobs=levelReq.executeRequirementStrategy(GameWindowPanel.coinage, 2);// Mobs to Lose Parameter = 2

		GameBoardTile.tower1RangeOfFire = Data.tower1RangeOfFire + 0; //set range of shooting of tower1.
		GameBoardTile.tower2RangeOfFire = Data.tower2RangeOfFire + 1; //set range of shooting of tower2.
		GameBoardTile.tower3RangeOfFire = Data.tower3RangeOfFire + 2; //set range of shooting of tower3.
	}
}}
