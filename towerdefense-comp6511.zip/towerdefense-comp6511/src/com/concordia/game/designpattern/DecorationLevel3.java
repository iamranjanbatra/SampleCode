package com.concordia.game.designpattern;

public class DecorationLevel3 extends GameLevelDecorator
{

	public DecorationLevel3(ILevelDecorator gameLevelDecorator) 
	{
		super(gameLevelDecorator);
	}
	public String tipToWin()
	{
		return super.tipToWin() + ",3";
	}
	public String gameMessage()
	{
		return super.gameMessage() + ",Numbers";
	}
}
