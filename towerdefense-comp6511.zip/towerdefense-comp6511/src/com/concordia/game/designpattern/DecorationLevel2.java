package com.concordia.game.designpattern;

public class DecorationLevel2 extends GameLevelDecorator
{

	public DecorationLevel2(ILevelDecorator gameLevelDecorator)
	{
		super(gameLevelDecorator);
	}
	public String tipToWin()
	{
		return super.tipToWin() + ",Near Start Point";
	}
	public String gameMessage()
	{
		return super.gameMessage() + ",Placement";
	}

}
