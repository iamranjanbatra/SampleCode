package com.concordia.game.designpattern;

public abstract class ILevelDecorator 
{
    public abstract String tipToWin();
	public abstract String gameMessage();
}
