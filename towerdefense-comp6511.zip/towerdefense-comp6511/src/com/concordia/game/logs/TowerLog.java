package com.concordia.game.logs;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import com.concordia.game.view.GameWindow;
/**
 * Towerlog controls all the implementation of log files related to individual towers and collection of towers
 * as required.
 */
public class TowerLog extends JFrame
{
	
	public static String path;
	/**
	 * towerLog() method implements the log implementation of towers and states the different log files to different towers
	 * @throws IOException if file is loaded or not 
	 */
	public static void towerLog() throws IOException
	{
		JFrame frame=new JFrame(); 	
		JPanel panel = new JPanel();
		
		panel.setBorder((Border) new TitledBorder(new EtchedBorder(), "logs"));
		
		panel.setSize(600,600);
		frame.add(panel);
		
		frame.setVisible(true);
		frame.setTitle("Logs");
		frame.setSize(650, 650);
		frame.setLocation(200,200);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		try
		{
		if(GameWindow.towerReference ==0)
		{	
		 path="logAllTowers.txt";
		}
		else if(GameWindow.towerReference==1)
		{
		 path="logTower1.txt";
		}
		else if(GameWindow.towerReference ==2)
		{
		 path="logTower2.txt";
		}
		else if(GameWindow.towerReference ==3)
		{
		 path="logTower3.txt";
		}
		else if(GameWindow.towerReference ==4)
		{
		 path="logFile.txt";
		}
		
		BufferedReader br = new BufferedReader(new FileReader(path));
		JTextArea towerTextArea = new JTextArea(30,45);
		towerTextArea.setEditable(false);
		
		String line;
		while (( line=br.readLine()) != null)
		{
			towerTextArea.append(line + "\n");
		
		}
		
		JScrollPane scroll = new JScrollPane (towerTextArea);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		panel.add(scroll);
		
		br.close();
		}
		catch(IOException i)
		{
		
		}
	
  }
}
