package com.concordia.game.test;
import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.*;
import com.concordia.game.model.Data;
import com.concordia.game.model.GameBoard;
import com.concordia.game.model.GameStore;
import com.concordia.game.model.MapBoard;
import com.concordia.game.model.MapLoad;
import com.concordia.game.model.MapTile;
import com.concordia.game.model.GameCritter;
import com.concordia.game.model.GameBoardTile;
import com.concordia.game.view.GameWindowPanel;
import com.concordia.game.view.GameWindow;
import com.concordia.game.view.map.MapWindow;
import com.concordia.game.view.menu.LoadMaps;
import com.concordia.game.view.menu.MapDimension;
import com.concordia.game.designpattern.*;
import com.concordia.game.model.TowerLog;

/**
 * Class containing all the test cases related to other than the categorised
 */
public class TestOther
{
	private int boardWidth;
	private int boardHeight;
	private String fileName;
	private int[] buttonPrice = new int[1];
	private int currentCoinage;
	private int sellingPrice;
	GameBoard gameboard;
	MapBoard mapboard;
	private int costPrice;
	GameCritter gamecritter;
	GameBoardTile gameboardtile;
	private int mobID;
	MapDimension mapdimension;
	GameWindowPanel gamewindowpanel;
	LoadMaps loadmaps;
	GameWindow gamewindow;
	MapWindow mapWindow;
	MapLoad mapLoad;
	FactoryLevel1 factorylevel1;
	GameLevelFactory gamelevelfactory;
	StrategyLevel3 strategylevel3;
	BasicLevelDecoration level1dec;
	TowerLog towerlog;
		
	@Before
	/**
	 * use to define context. 
	  **/
	public void defineContext()
	{
		boardWidth = 10;
		boardHeight = 8;
		fileName = "testCaseFile";
		buttonPrice[0] = 10;
		sellingPrice = 5;
		currentCoinage = GameWindowPanel.coinage;
		gameboard = new GameBoard();
		costPrice = 20;
		mapboard = new MapBoard();
		gamecritter = new GameCritter();
		mobID = 0;
		gameboardtile = new GameBoardTile(100,100,100,100,1);
		mapdimension = new MapDimension();
		loadmaps = new LoadMaps();
		gamewindow = new GameWindow();
		mapWindow = new MapWindow();
		mapLoad = new MapLoad();
		GameWindowPanel.loadFileName = fileName;
		factorylevel1 = new FactoryLevel1();
		gamelevelfactory = new GameLevelFactory(1);
		strategylevel3 = new StrategyLevel3();
		level1dec = new BasicLevelDecoration();
	}

	@Test
	/**
	 * 4
	 * use to test the change in price by buying the tower.
	 * use to test the change in price by comparing the buttonPrice with purchaceTower value.
	 * */
	public void testTowerPurchase()
	{
		GameStore store = new GameStore();
		assertEquals(currentCoinage - buttonPrice[0], store.purchaseTower(buttonPrice, 0)); //check whether point in account is changed or not while purchasing tower.
	}
	
	@Test
	/**
	 * 5
	 * use to test the change in price by selling the tower.
	 * use to test the change in price by comparing the sellingPrice with GameStore class value.
	 * */
	public void testTowerSell()
	{
		GameStore store = new GameStore();
		assertEquals(currentCoinage + sellingPrice, store.sellChosenTower(GameStore.tower1SellingPrice));//check whether point in account is changed or not while selling tower.
	}
	
	@Test
	/**
	 * 7
	 * use to test the change in price by upgrading the tower.
	 * use to test the change in price by comparing the costPrice with GameStore class value.
	 * */
	public void testTowerUpgrade()
	{
		GameStore store = new GameStore();
		assertEquals(currentCoinage - costPrice, store.upgradeChosenTower(GameStore.tower2CostPrice));//check whether tower is updated or not.
		//check the change in price
	}
	
	@Test
	/**
	 * 16
	 * use to test whether critter health has a value or not.
	 * */
	public void testCritterHealth() 
	{	
		assertNotNull(gamecritter.health);
	}

	@Test
	/**
	 * 17
	 * use to test whether loose health works or not.
	 * */
	public void testLooseHealth() 
	{
		int tmphealth = GameWindowPanel.health;
		GameWindowPanel.health=2;
		gamecritter.looseHealth();
		assertEquals(GameWindowPanel.health,1);
		GameWindowPanel.health = tmphealth;

	}

	@Test
	/**
	 * 18
	 * use to test whether lose health works or not.
	 * */
	public void testLoseHealth() 
	{
		int temp = gamecritter.health;
		gamecritter.health = 10;
		gamecritter.loseHealth(4,Data.tower1);
		assertEquals(gamecritter.health,6);
		gamecritter.health = temp;
	}

	@Test
	/**
	 * 19
	 * use to test whether get money works or not.
	 * */
	public void testgetMoney() 
	{
		int tmpcoinage = GameWindowPanel.coinage;
		gameboardtile.getMoney(mobID);
		assertEquals(GameWindowPanel.coinage,tmpcoinage+Data.deathReward[mobID]);
		GameWindowPanel.coinage = tmpcoinage;
	}

	@Test
	/**
	 * 20
	 * use to test the whether isDead method works or not.
	 * */
	public void testisDead()
	{
		boolean tmpingame = gamecritter.inGame;
		gamecritter.inGame = true;
		assertFalse(gamecritter.isDead());
		gamecritter.inGame = tmpingame;
	}

	@Test
	/**
	 * 21
	 * use to test the whether mob title is set or not.
	 * */
	public void testtitlesetmob()
	{
		assertNotNull(gamecritter.tiletSetMob);
	}

	@Test
	/**
	 * 22
	 * use to test the whether hasWon method works or not.
	 * */
	public void testhaswon()
	{
		int tmpkilled = GameWindowPanel.killed;
		int tmpkillstowin = GameWindowPanel.killsToWin;
		boolean tmpiswin = GameWindowPanel.isWin;
		GameWindowPanel.killed=0;

		GameWindowPanel.killsToWin=0;
		GameWindowPanel.hasWon();
		assertTrue(GameWindowPanel.isWin);

		GameWindowPanel.killed = tmpkilled;
		GameWindowPanel.killsToWin = tmpkillstowin;
		GameWindowPanel.isWin = tmpiswin;
	}

	@Test
	/**
	 * 23
	 * use to test the whether defineCoinage method works or not.
	 * */
	public void testgwpdefine()
	{
		assertNotNull(GameWindowPanel.store);
	}

	@Test
	/**
	 * 26
	 * use to test the whether screen of window is added or not.
	 * */
	public void testgwscreen()
	{
		assertNotNull(GameWindow.screen);
	}

	@Test
	/**
	 * 27
	 * use to test the whether frame of window is added or not.
	 * */
	public void testgwframe()
	{
		GameWindow.drawGameWindow();
		assertNotNull(GameWindow.frame);
	}

	@Test
	/**
	 * 28
	 * use to test the whether panel of window is added or not.
	 * */
	public void testgwpanel()
	{
		GameWindow.drawGameWindow();
		assertNotNull(GameWindow.panel);
	}

	@Test
	/**
	 * 29
	 * use to test the whether start button of window is added or not.
	 * */
	public void testgwstartbutton()
	{
		GameWindow.drawGameWindow();
		assertNotNull(GameWindow.startButton);
	}
	
	@Test
	/**
	 * 31
	 * use to test the whether tile of critter is set or not.
	 * */
	public void testcrittertileset()
	{
		assertNotNull(gamecritter.tiletSetMob);
	}
	
	@Test
	/**
	 * 34
	 * use to test the whether define method of gamestore is set or not.
	 * */
	public void testgamestoredefine()
	{
		GameStore store = new GameStore();
		store.define();
		assertNotNull(store.button);
	}
	
	@Test
	/**
	 * 37
	 * use to test the whether drawmapwindow of mapwindow is set or not.
	 * */
	public void testdrawmapwindow()
	{
		mapWindow.drawMapWindow();
		assertEquals(mapWindow.isMapValidL,mapWindow.validateMap());
	}

	@Test
	/**
	 * 38
	 * use to test the whether defineCoinage is set or not.
	 * */
	public void testdefineCoinage()
	{
		gamewindowpanel = new GameWindowPanel();
		gamewindowpanel.mobCounter=1;
		gamewindowpanel.defineCoinage();
		assertEquals(gamewindowpanel.mobCounter,0);
	}

	@Test
	/**
	* 39
	* use to test the whether mapsquare is set or not.
	* */
	public void testmapsquare()
	{
		MapTile maptile = new MapTile(10,10,boardWidth,boardHeight,0);
		assertNotNull(maptile.mapSquare);
	}

	@Test
	/**
	* 40
	* use to test the whether physic of gameboardtile works or not.
	* */
	public void testphysic()
	{
		GameBoardTile gbt = new GameBoardTile(10,10,boardWidth,boardHeight,0);
		boolean tmpshooting = gbt.shooting;
		int tmpshotmob = gbt.shotMob;
		gbt.shooting=true;
		gbt.shotMob = -1;
		gbt.physic();
		assertFalse(gbt.shooting);
		gbt.shooting=tmpshooting;
		gbt.shotMob = tmpshotmob;
	}
	
	@Test
	/**
	 * 41
	 * use to test the whether deletemob of gamecritter works or not.
	 * */
	public void testdeletemob()
	{
		int tmphealth = gamecritter.health;
		int tmpcoinage = GameWindowPanel.coinage;
		gamecritter.health = 52;
		gamecritter.deleteMob();
		assertEquals(GameWindowPanel.coinage,tmpcoinage-5);
		gamecritter.health = tmphealth;
		GameWindowPanel.coinage = tmpcoinage;
	}
	
	@Test
	/**
	 * 42
	 * use to test the whether reducecoins of gamecritter works or not.
	 * */
	public void testreducecoins()
	{
		int tmpcoinage = GameWindowPanel.coinage;
		gamecritter.reduceCoins(10);
		assertEquals(GameWindowPanel.coinage,tmpcoinage-10);
		GameWindowPanel.coinage = tmpcoinage;
	}
	
	@Test
	/**
	 * 43
	 * use to test the whether getSpecification of factorylevel1 works or not.
	 * */
	public void testfactorylevel1()
	{
		assertEquals("Beginner",factorylevel1.getSpecification());
	}
	
	@Test
	/**
	 * 44
	 * use to test the whether getSpecification of factorylevel1 works or not.
	 * */
	public void testfactorylevel11()
	{
		assertEquals(60,factorylevel1.getCoinage());
	}
	
	@Test
	/**
	 * 45
	 * use to test the whether setlevels of gamelevelfactory works or not.
	 * */
	public void testsetlevels()
	{
		gamelevelfactory.setLevels(2);
		assertEquals(GameBoardTile.tower2RangeOfFire,Data.tower2RangeOfFire + 1);
	}
	
	@Test
	/**
	 * 46
	 * use to test the whether setlevels of gamelevelfactory works or not.
	 * */
	public void teststrategylevel3()
	{
		assertEquals(strategylevel3.requirements(71, 1),71+10);
	}
	
	@Test
	/**
	 * 47
	 * use to test the whether tipToWin of level1decorator works or not.
	 * */
	public void testleveldecorator()
	{
		assertEquals(level1dec.tipToWin(),"Red");
	}
	
	@Test
	/**
	 * 48
	 * use to test the whether gamemessage of level1decorator works or not.
	 * */
	public void testlevel1decorator()
	{
		assertEquals(level1dec.gameMessage(),"Tower Selection");
	}
	
	@Test
	/**
	 * 49
	 * use to test the whether towerlog works or not.
	 * */
	public void testtowerlog() throws IOException
	{
		int tmpref = GameWindow.towerReference;
		GameWindow.towerReference = 1;
		TowerLog.towerLog();
		assertEquals("logTower1.txt",towerlog.path);
		GameWindow.towerReference = tmpref;
	}
	
	@Test
	/**
	 * 50
	 * use to test the whether decoratorFunctionality of game store works or not.
	 * */
	public void testdecfunc()
	{
		int tmplevel = GameWindowPanel.level;
		GameWindowPanel.level = 1;
		GameStore store = new GameStore();
		store.decoratorFunctionality();
		assertEquals("Tower Selection",store.stringGameMessage);
		GameWindowPanel.level = tmplevel;
		
	}
	
}
