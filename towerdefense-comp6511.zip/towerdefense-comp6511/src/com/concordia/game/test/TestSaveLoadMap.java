package com.concordia.game.test;
import static org.junit.Assert.*;

import java.io.File;

import org.junit.*;
import com.concordia.game.model.Data;
import com.concordia.game.model.GameBoard;
import com.concordia.game.model.GameLoad;
import com.concordia.game.model.GameStore;
import com.concordia.game.model.MapBoard;
import com.concordia.game.model.MapLoad;
import com.concordia.game.model.MapTile;
import com.concordia.game.model.GameCritter;
import com.concordia.game.model.GameBoardTile;
import com.concordia.game.view.GameWindowPanel;
import com.concordia.game.view.GameWindow;
import com.concordia.game.view.map.MapWindow;
import com.concordia.game.view.menu.LoadMaps;
import com.concordia.game.view.menu.MapDimension;
/**
 * Class containing all the test cases related to map save and load
 */
public class TestSaveLoadMap 
{

	private int boardWidth;
	private int boardHeight;
	private String fileName;
	private int[] buttonPrice = new int[1];
	private int currentCoinage;
	private int sellingPrice;
	GameBoard gameboard;
	MapBoard mapboard;
	private int costPrice;
	GameCritter gamecritter;
	GameBoardTile gameboardtile;
	private int mobID;
	MapDimension mapdimension;
	GameWindowPanel gamewindowpanel;
	LoadMaps loadmaps;
	GameWindow gamewindow;
	MapWindow mapWindow;
	MapLoad mapLoad;
		
	@Before
	/**
	 * use to define context. 
	  **/
	public void defineContext()
	{
		boardWidth = 10;
		boardHeight = 8;
		fileName = "testCaseFile";
		buttonPrice[0] = 10;
		sellingPrice = 5;
		currentCoinage = GameWindowPanel.coinage;
		gameboard = new GameBoard();
		costPrice = 20;
		mapboard = new MapBoard();
		gamecritter = new GameCritter();
		mobID = 0;
		gameboardtile = new GameBoardTile(100,100,100,100,1);
		mapdimension = new MapDimension();
		loadmaps = new LoadMaps();
		gamewindow = new GameWindow();
		mapWindow = new MapWindow();
		mapLoad = new MapLoad();
		GameWindowPanel.loadFileName = fileName;
	}

	@Test
	/**
	 * 1
	 * use to check the dimensions limit.
	 * use to do the test on dimensions by passing the value to mapDimension class
	 * **/
	public void testMapDimension()
	{ //check whether dimension is properly checked or not.
		assertTrue("Board width should be less than or equal to " + Data.maxBoardWidth, mapdimension.setBoardWidth(boardWidth));
		assertTrue("Board height should be less than or equal to " + Data.maxBoardHeight, mapdimension.setBoardHeight(boardHeight));
	}
	
	@Test
	/**
	 * 2
	 * use to test weather map is saved or not.
	 * use to test by comparing fileName and value from mapWindow class.
	 * */
	public void testSaveFile()
	{	
		assertTrue("Is File Saved: ", MapWindow.saveFile(fileName)); //check whether map is saved or not.
	}
	
	@Test
	/**
	 * 3
	 * use to test weather map is loaded or not.
	 * use to test by comparing fileName and value from mapLoad class.
	 * */
	public void testMapLoadFile()
	{		
		assertTrue("Is Map File loaded: ", mapLoad.loadWorld(new File("savedMaps/" + fileName))); //check whether map is load or not.
	}
	
	@Test
	/**
	 * 6
	 * use to test either tile is loaded on map or not.
	 * use to test the tile is loaded on map or not.
	 * */
	public void testTileCreation() 
	{	
		assertNotNull(gameboard.tile); //check whether map is created or not.
	}
	
	@Test
	/**
	 * 8
	 * use to test either board is loaded on map or not.
	 * use to test the board is loaded on map or not.
	 * */
	public void testBlockCreation()
	{	
		assertNotNull(mapboard.block); //check whether map is created or not
	}
	
	@Test
	/**
	 * 10
	 * use to test weather map is loaded or not.
	 * use to test by comparing with LoadMaps
	 * */
	public void testLoadMaps()
	{
		assertTrue("Are all the maps loaded: ", LoadMaps.loadMaps().getValueAt(0, 0) != null); //check whether map is loaded or not.
	}
	
	@Test

	/**
	 * 11
	 * use to test either world height value is passed or not
	 * */
	public void testWorldHeight() 
	{	
		assertNotNull(mapboard.worldHeight);
	}

	@Test
	/**
	 * 12
	 * use to test either world width value is passed or not
	 * */
	public void testWorldWidth()
	{	
		assertNotNull(mapboard.worldWidth);
	}

	@Test
	/**
	 * 13
	 * use to test if map is checked for validation or not.
	 * */
	public void testMapValidate() 
	{	
		MapWindow mapWindow = new MapWindow();
		assertNotNull(mapWindow.validateMap()); //check the map is properly validate or not.
	}
	
	@Test
	/**
	 * 24
	 * use to test the whether height of play map is saved.
	 * */

	public void testloadmaps1()
	{
		assertNotNull(GameBoard.boardHeight);

	}

	@Test
	/**
	 * 25
	 * use to test the whether width of play map is saved.
	 * */
	public void testloadmaps2()
	{
		assertNotNull(GameBoard.boardWidth);
	}
}
