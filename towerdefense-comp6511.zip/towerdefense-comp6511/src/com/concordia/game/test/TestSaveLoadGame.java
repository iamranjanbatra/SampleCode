package com.concordia.game.test;
import static org.junit.Assert.*;

import java.io.File;

import org.junit.*;
import com.concordia.game.model.Data;
import com.concordia.game.model.GameBoard;
import com.concordia.game.model.GameLoad;
import com.concordia.game.model.GameStore;
import com.concordia.game.model.MapBoard;
import com.concordia.game.model.MapLoad;
import com.concordia.game.model.MapTile;
import com.concordia.game.model.GameCritter;
import com.concordia.game.model.GameBoardTile;
import com.concordia.game.view.GameWindowPanel;
import com.concordia.game.view.GameWindow;
import com.concordia.game.view.map.MapWindow;
import com.concordia.game.view.menu.LoadMaps;
import com.concordia.game.view.menu.MapDimension;
/**
 * 
 * define the parameters used for testing the price change while selling ,upgrading or buying.
 *
 */
public class TestSaveLoadGame 
{
	private int boardWidth;
	private int boardHeight;
	private String fileName;
	private int[] buttonPrice = new int[1];
	private int currentCoinage;
	private int sellingPrice;
	GameBoard gameboard;
	MapBoard mapboard;
	private int costPrice;
	GameCritter gamecritter;
	GameBoardTile gameboardtile;
	private int mobID;
	MapDimension mapdimension;
	GameWindowPanel gamewindowpanel;
	LoadMaps loadmaps;
	GameWindow gamewindow;
	MapWindow mapWindow;
	MapLoad mapLoad;
		
	@Before
	/**
	 * use to define context. 
	  **/
	public void defineContext()
	{
		boardWidth = 10;
		boardHeight = 8;
		fileName = "testCaseFile";
		buttonPrice[0] = 10;
		sellingPrice = 5;
		currentCoinage = GameWindowPanel.coinage;
		gameboard = new GameBoard();
		costPrice = 20;
		mapboard = new MapBoard();
		gamecritter = new GameCritter();
		mobID = 0;
		gameboardtile = new GameBoardTile(100,100,100,100,1);
		mapdimension = new MapDimension();
		loadmaps = new LoadMaps();
		gamewindow = new GameWindow();
		mapWindow = new MapWindow();
		mapLoad = new MapLoad();
		GameWindowPanel.loadFileName = fileName;
	}

	@Test
	/**
	 * 9
	 * use to test whether game is loaded or not.
	 * use to test by comparing with gameLoad
	 * */
	public void testGameLoadFile()
	{
		MapLoad gameLoad = new MapLoad();
		assertTrue("Is Game File loaded: ", gameLoad.loadWorld(new File("savedMaps/" + fileName)));//check whether map is loaded or not.
	}
	
	@Test

	/**
	 * 14
	 * use to test either game board width value is set or not
	 * */
	public void testBoardWidth() 
	{	
		assertNotNull(gameboard.boardWidth);
	}

	@Test
	/**
	 * 15
	 * use to test either game board height value is set or not
	 * */
	public void testBoardHeight() 
	{	
		assertNotNull(gameboard.boardHeight);
	}
	
	@Test
	/**
	 * 30
	 * use to test the whether tile of gameboard is set or not.
	 * */
	public void testgbtile()
	{
		gameboard.define();
		assertNotNull(gameboard.tile);
	}
}
