package com.concordia.game.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class) //to run the test class
@SuiteClasses({
	TestOther.class,
	TestSaveLoadMap.class,
	TestSaveLoadGame.class,
	TestTargetingStrategies.class,
	TestSpecialDamageEffects.class
	})
/**
 * testSuite contains test classes.
 * */
public class TestSuite
{

}
