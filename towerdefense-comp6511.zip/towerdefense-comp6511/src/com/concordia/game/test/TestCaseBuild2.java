package com.concordia.game.test;

import static org.junit.Assert.*;
import java.io.File;
import org.junit.*;

import com.concordia.game.model.Data;

import com.concordia.game.model.GameBoard;
import com.concordia.game.model.GameLoad;

import com.concordia.game.model.GameStore;

import com.concordia.game.model.MapBoard;

import com.concordia.game.model.MapLoad;

import com.concordia.game.model.MapTile;

import com.concordia.game.model.GameCritter;

import com.concordia.game.model.GameBoardTile;

import com.concordia.game.view.GameWindowPanel;

import com.concordia.game.view.GameWindow;

import com.concordia.game.view.map.MapWindow;

import com.concordia.game.view.map.MapWindowPanel;

import com.concordia.game.view.menu.LoadMaps;

import com.concordia.game.view.menu.MapDimension;

/**

 * 

 * define the parameters used for testing the price change while selling ,upgrading or buying.

 *

 */

public class TestCaseBuild2 

{

	private int boardWidth;

	private int boardHeight;

	private String fileName;

	private int[] buttonPrice = new int[1];

	private int currentCoinage;

	private int sellingPrice;

	GameBoard gameboard;

	MapBoard mapboard;

	private int costPrice;

	GameCritter gamecritter;

	GameBoardTile gameboardtile;

	private int mobID;

	MapDimension mapdimension;

	GameWindowPanel gamewindowpanel;

	LoadMaps loadmaps;

	GameWindow gamewindow;

	MapWindow mapWindow;

	MapLoad mapLoad;

	MapWindowPanel mapwindowpanel;

		

	@Before

	/**

	 * use to define context. 

	  **/

	public void defineContext()

	{

		boardWidth = 10;

		boardHeight = 8;

		fileName = "testCaseFile";

		buttonPrice[0] = 10;

		sellingPrice = 5;

		currentCoinage = GameWindowPanel.coinage;

		gameboard = new GameBoard();

		costPrice = 20;

		mapboard = new MapBoard();

		gamecritter = new GameCritter();

		mobID = 0;

		gameboardtile = new GameBoardTile(100,100,100,100,1);

		mapdimension = new MapDimension();

		//gameboard.tile = new GameBoardTile[boardHeight][boardWidth];

		//gamewindowpanel = new GameWindowPanel();

		loadmaps = new LoadMaps();

		gamewindow = new GameWindow();

		mapWindow = new MapWindow();

		mapLoad = new MapLoad();

		GameWindowPanel.loadFileName = fileName;

		mapwindowpanel = new MapWindowPanel(mapWindow);

		

	}

	

	@Test

	/**

	 * 11

	 * use to test either world height value is passed or not

	 * */

	public void testWorldHeight() 

	{	

		assertNotNull(mapboard.worldHeight);

	}

	

	@Test

	/**

	 * 12

	 * use to test either world width value is passed or not

	 * */

	public void testWorldWidth()

	{	

		assertNotNull(mapboard.worldWidth);

	}

	

	@Test

	/**

	 * 13

	 * use to test if map is checked for validation or not.

	 * */

	public void testMapValidate() 

	{	

		MapWindow mapWindow = new MapWindow();

		assertNotNull(mapWindow.validateMap()); //check the map is properly validate or not.

	}

	

	@Test

	/**

	 * 14

	 * use to test either game board width value is set or not

	 * */

	public void testBoardWidth() 

	{	

		assertNotNull(gameboard.boardWidth);

	}

	

	@Test

	/**

	 * 15

	 * use to test either game board height value is set or not

	 * */

	public void testBoardHeight() 

	{	

		assertNotNull(gameboard.boardHeight);

	}

	

	@Test

	/**

	 * 16

	 * use to test whether critter health has a value or not.

	 * */

	public void testCritterHealth() 

	{	

		assertNotNull(gamecritter.health);

	}

	

	@Test

	/**

	 * 17

	 * use to test whether loose health works or not.

	 * */

	public void testLooseHealth() 

	{

		gamecritter.looseHealth();

		assertEquals(GameWindowPanel.health,9);

	}

	

	@Test

	/**

	 * 18

	 * use to test whether lose health works or not.

	 * */

	public void testLoseHealth() 

	{

		int temp = gamecritter.health;

		gamecritter.health = 10;

		gamecritter.loseHealth(4,Data.tower1);

		assertEquals(gamecritter.health,6);

		gamecritter.health = temp;

	}


	@Test
	/**
	 * 19
	 * use to test weather map is saved or not.
	 * use to test by comparing fileName and value from mapWindow class.
	 * */
	public void testSaveFile()
	{	
		assertTrue("Is File Saved: ", MapWindow.saveFile(fileName)); //check whether map is saved or not.
	}

	@Test

	/**

	 * 20

	 * use to test the whether isDead method works or not.

	 * */

	public void testisDead()

	{

		

		gamecritter.inGame = true;

		assertFalse(gamecritter.isDead());

	}

	

	@Test

	/**

	 * 21

	 * use to test the whether mob title is set or not.

	 * */

	public void testtitlesetmob()

	{

		assertNotNull(gamecritter.tiletSetMob);

	}

	

	@Test

	/**

	 * 22

	 * use to test the whether hasWon method works or not.

	 * */

	public void testhaswon()

	{

		GameWindowPanel.killed=0;

		GameWindowPanel.killsToWin=0;

		GameWindowPanel.hasWon();

		assertTrue(GameWindowPanel.isWin);

	}

		

	@Test

	/**

	 * 23

	 * use to test the whether defineCoinage method works or not.

	 * */

	public void testgwpdefine()

	{

		

		assertNotNull(GameWindowPanel.store);

	}

	

	@Test

	/**

	 * 24

	 * use to test the whether height of play map is saved.

	 * */

	public void testloadmaps1()

	{

		LoadMaps.setWidthAndHeightPlaymap(new File("savedMaps/" + fileName));

		assertNotNull(GameBoard.boardHeight);

	}

	

	@Test

	/**

	 * 25

	 * use to test the whether width of play map is saved.

	 * */

	public void testloadmaps2()

	{

		LoadMaps.setWidthAndHeightPlaymap(new File("savedMaps/" + fileName));

		assertNotNull(GameBoard.boardWidth);

	}

	

	@Test

	/**

	 * 26

	 * use to test the whether screen of window is added or not.

	 * */

	public void testgwscreen()

	{

		assertNotNull(GameWindow.screen);

	}

	

	@Test

	/**

	 * 27

	 * use to test the whether frame of window is added or not.

	 * */

	public void testgwframe()

	{

		GameWindow.drawGameWindow();

		assertNotNull(GameWindow.frame);

	}

	

	@Test

	/**

	 * 28

	 * use to test the whether panel of window is added or not.

	 * */

	public void testgwpanel()

	{

		GameWindow.drawGameWindow();

		assertNotNull(GameWindow.panel);

	}

	

	@Test

	/**

	 * 29

	 * use to test the whether start button of window is added or not.

	 * */

	public void testgwstartbutton()

	{

		GameWindow.drawGameWindow();

		assertNotNull(GameWindow.startButton);

	}

	

	@Test

	/**

	 * 30

	 * use to test the whether tile of gameboard is set or not.

	 * */

	public void testgbtile()

	{

		gameboard.define();

		assertNotNull(gameboard.tile);

	}

	

	@Test

	/**

	 * 31

	 * use to test the whether tile of critter is set or not.

	 * */

	public void testcrittertileset()

	{

		assertNotNull(gamecritter.tiletSetMob);

	}

	

	@Test

	/**

	 * 32

	 * use to test the whether set has frozen of critter is set or not.

	 * */

	public void testcrittersetfrozen()

	{

		gamecritter.setHasFrozen(true);

		assertTrue(gamecritter.getHasFrozen());

	}

	

	@Test

	/**

	 * 33

	 * use to test the whether set freeze of critter is set or not.

	 * */

	public void testcrittersetfreeze()

	{

		gamecritter.setFreeze();

		assertTrue(gamecritter.getFreeze());

	}

	

	@Test

	/**

	 * 34

	 * use to test the whether define method of gamestore is set or not.

	 * */

	public void testgamestoredefine()

	{

		GameStore store = new GameStore();

		store.define();

		assertNotNull(store.button);

	}

	

	@Test

	/**

	 * 35

	 * use to test the whether define method of gamestore is set or not.

	 * */

	public void testincreaserange()

	{

		GameStore store = new GameStore();

		GameWindowPanel.coinage = store.tower1CostToIncreaseRange;

		store.increaseRange(10, 10, Data.tower1);

		assertEquals(GameBoardTile.tower1SquareSize,70);

	}

	

	@Test

	/**

	 * 36

	 * use to test the whether define method of gamestore is set or not.

	 * */

	public void testincreaseRateOfFire()

	{

		GameStore store = new GameStore();

		GameWindowPanel.coinage=store.tower1CostToIncreaseRateOfFire;

		store.increaseRateOfFire(10, 10, Data.tower1);

		assertEquals(GameBoardTile.tower1RangeOfFire,2);

	}

	

	@Test

	/**

	 * 37

	 * use to test the whether drawmapwindow of mapwindow is set or not.

	 * */

	public void testdrawmapwindow()

	{

		mapWindow.drawMapWindow();

		assertEquals(mapWindow.isMapValidL,mapWindow.validateMap());

	}

	

	@Test

	/**

	 * 38

	 * use to test the whether defineCoinage is set or not.

	 * */

	public void testdefineCoinage()

	{

		gamewindowpanel = new GameWindowPanel();

		gamewindowpanel.mobCounter=1;

		gamewindowpanel.defineCoinage();

		assertEquals(gamewindowpanel.mobCounter,0);

	}

	
	@Test
	/**
	 * 39
	 * use to check the dimensions limit.
	 * use to do the test on dimensions by passing the value to mapDimension class
	 * **/
	public void testMapDimension()
	{ //check whether dimension is properly checked or not.
		assertTrue("Board width should be less than or equal to " + Data.maxBoardWidth, mapdimension.setBoardWidth(boardWidth));
		assertTrue("Board height should be less than or equal to " + Data.maxBoardHeight, mapdimension.setBoardHeight(boardHeight));
	}

	@Test

	/**

	 * 40

	 * use to test the whether mapsquare is set or not.

	 * */

	public void testmapsquare()

	{

		MapTile maptile = new MapTile(10,10,boardWidth,boardHeight,0);

		assertNotNull(maptile.mapSquare);

	}

	


	
}