package com.concordia.game.model;
import java.io.*;
import java.util.*;

import com.concordia.game.view.GameWindow;
import com.concordia.game.view.GameWindowPanel;

/**
 *  The GameLoad class gets the height and width of grid and then loads the game board.
 */
public class GameLoad
{
    public static File loadPath;
    
    public ArrayList<Integer> topScores5;
    /**
     *  Responsible for loading the game board by getting the height and width of map from user.
     *  
     *  @param loadPath Represents the file load path.
     *  @return map is loaded or not.
     *  
     */
    public boolean loadWorld(File loadPath)
    {
        this.loadPath = loadPath;
        try
        {            
            Scanner loadScanner = new Scanner(loadPath);
            if(loadScanner.hasNext())
            {
                if(GameBoard.boardHeight == 0)
                {
                    GameBoard.boardHeight = Integer.parseInt(loadScanner.next()); // get the height of map from user.
                }
                else
                {
                    loadScanner.next();
                }            
            }
            if(loadScanner.hasNext())
            {
                if(GameBoard.boardWidth == 0)
                {
                    GameBoard.boardWidth = Integer.parseInt(loadScanner.next());  // get the width of map from user.
                }
                else
                {
                    loadScanner.next();
                }
            }
            
            if(loadScanner.hasNext())
            {                
                GameWindowPanel.level = Integer.parseInt(loadScanner.next());            
            }
                        
            while(loadScanner.hasNext())
            {
                for(int y = 0; y < GameBoard.boardHeight; y++)
                {
                    for(int x = 0; x < GameBoard.boardWidth; x++)
                    {
                        String val = loadScanner.next(); 
                        GameWindowPanel.room.tile[y][x].groundID = Integer.parseInt(val); //call the GameWindowPanel
                    }
                }
                break;
            }
            
            GameWindow.topScores = new ArrayList<Integer>();
            
            while(loadScanner.hasNext())
            {
                GameWindow.topScores.add(Integer.parseInt(loadScanner.next()));                
            }
            
            GameStore.totalScore = GameWindow.topScores.get(GameWindow.topScores.size() - 1);
            
            Collections.sort(GameWindow.topScores, Collections.reverseOrder());
            
            loadScanner.close();
            return true; 
        }
        catch(Exception e)
        {            
             //ex.printStackTrace();                    
        }    
        return false;
    }
}