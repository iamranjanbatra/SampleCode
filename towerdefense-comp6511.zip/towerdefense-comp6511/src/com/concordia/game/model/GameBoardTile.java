package com.concordia.game.model;
import java.awt.*;
import java.util.Timer;
import java.util.TimerTask;
import org.apache.log4j.Appender;
import org.apache.log4j.Logger;

import com.concordia.game.view.GameWindowPanel;
import com.concordia.game.view.menu.LoadMaps;

import org.apache.log4j.*;
/** GameBoardTile class is used to implement the the board tile around the different
 *  towers when selected and hovered
 */
public class GameBoardTile extends Rectangle 
{
	private static final long serialVersionUID = -3562743020155287826L;
	public Rectangle towerSquare;
	public Rectangle transparentTowerSquare;
	public int towerSquareSize = 50;
	public static int shootingt1count=0;
	public static int shootingt2count=0;
	public static int shootingt3count=0;
	public static int tower1SquareSize = 50;
	public static int tower2SquareSize = 70;
	public static int tower3SquareSize = 100;
	public static int tower1RangeOfFire = 1;
	public static int tower2RangeOfFire = 2;
	public static int tower3RangeOfFire = 3;
	public int groundID;
	public static int loseTime = 100, loseFrame = 0;
	public boolean tower1Selected=true;
	public boolean tower2Selected=true;
	public boolean tower3Selected=true;
	public boolean tower1Shooting=true;
	public boolean tower2Shooting=true;
	public boolean tower3Shooting=true;
	public boolean drawLine = true;
	static Logger loggerGameGlobal = Logger.getLogger("gameglobal");
	static Logger loggerTower1 = Logger.getLogger("tower1Alone");
	static Logger loggerTower2 = Logger.getLogger("tower2Alone");
	static Logger loggerTower3 = Logger.getLogger("tower3Alone");
	static Logger loggerAllTowers = Logger.getLogger("allTowers");
	static Logger loggerCritters = Logger.getLogger("critters");
	public int shotMob = -1;
	public static int logCount=0;
	public boolean shooting = false;
	
	/** GameBoardTile is the constructor method used to set the bounds of the tile 
	 * around the tower at specified place in the window.
	 * @param x x-coordinate of the tower
	 * @param y y-coordinate of the tower
	 * @param width width of the tile around tower
	 * @param height height of the tile around tower 
	 * @param groundID groundID where tower is placed
	 */
	public GameBoardTile(int x, int y, int width, int height, int groundID)
	{		
		this.groundID = groundID; //set tile of map
		
		setBounds(x, y, width, height);	//set width, height and point to draw map.
				
		towerSquare = new Rectangle(x - (towerSquareSize/2), y - (towerSquareSize/2), width + (towerSquareSize), height + (towerSquareSize));
		//implements the rectangle to create the tower on map and their shooting area.
	}
	
	/** draw() method used to implementation of game board tile
	 * @param the graphics object used to paint the frame.
	 */
	public void draw(Graphics g)
	{
		g.drawImage(GameWindowPanel.tileSetGround[groundID], x, y, width, height, null); 
		//call the tileSetGround function of GameWindowPanel.java to draw the map.
	}
	
	/**
	 * towerStrongestStrategy() method finds the critter with most power and implement shooting on them 
	 * to implement Strongest critter destruction strategy
	 */
	
	public void towerStrongestStrategy()
	{
		for(int i=52;i>=0;i--)
		{
			if(GameWindowPanel.mobs[shotMob].health==i)
			{
				shooting = true;
			}
			else
			{
				//do-nothing
			}
		}
	}
	/**
	 * towerStrongestStrategy() method finds the critter with least power and implement shooting on them 
	 * to implement weakest critter destruction strategy
	 */
	public void towerWeakestStrategy()
	{
		for(int i=0;i<=52;i++)
		{
			if(GameWindowPanel.mobs[shotMob].health==i)
			{
				shooting = true;
			}
			else
			{
				//do-nothing
			}
		}
	}
	/** 
	 * method used to define the height and width of the tile made around 
	 * the towers differently according to their capacities.
	 */
	public void physic()
	{		
		//Draw the selected tower on map by implementing rectangle.
		if(groundID == Data.tower1)
		{	
			towerSquare = new Rectangle(x - (tower1SquareSize/2), y - (tower1SquareSize/2), width + (tower1SquareSize), height + (tower1SquareSize));
			//specifies the width and height of tower1.
			transparentTowerSquare = new Rectangle(x - (tower1SquareSize/2), y - (tower1SquareSize/2), width + (tower1SquareSize), height + (tower1SquareSize));
		/*	if(logCount == 0)
			{
				loggerTowerPlacement.debug("Tower 1 is Selected" + logCount);
				logCount++;
			}*/
			if(tower1Selected)
			{
				loggerGameGlobal.info("Tower 1 is Selected");
				loggerAllTowers.info("Tower 1 is Selected");
				loggerTower1.info("Tower 1 is Selected");
				tower1Selected = false;
			}
			
		}
		else if(groundID == Data.tower2)
		{
			towerSquare = new Rectangle(x - (tower2SquareSize/2), y - (tower2SquareSize/2), width + (tower2SquareSize), height + (tower2SquareSize));
			//specifies the width and height of tower2
			transparentTowerSquare = new Rectangle(x - (tower2SquareSize/2), y - (tower2SquareSize/2), width + (tower2SquareSize), height + (tower2SquareSize));
			if(tower2Selected)
			{
				loggerGameGlobal.info("Tower 2 Selected");
				loggerAllTowers.info("Tower 2 is Selected");
				loggerTower2.info("Tower 2 is Selected");
				tower2Selected = false;
			}
			
			
		}
		else if(groundID == Data.tower3)
		{
			towerSquare = new Rectangle(x - (tower3SquareSize/2), y - (tower3SquareSize/2), width + (tower3SquareSize), height + (tower3SquareSize));	
			//specifies the width and height of tower3
			transparentTowerSquare = new Rectangle(x - (tower3SquareSize/2), y - (tower3SquareSize/2), width + (tower3SquareSize) + 50, height + (tower3SquareSize) + 50);
			if(tower3Selected)
			{
				loggerGameGlobal.info("Tower 3 Selected");
				loggerAllTowers.info("Tower 3 is Selected");
				loggerTower3.info("Tower 3 is Selected");
				tower3Selected = false;
			}	
		}
		
		if(shotMob != -1 && (towerSquare.intersects(GameWindowPanel.mobs[shotMob]) || (transparentTowerSquare.intersects(GameWindowPanel.mobs[shotMob]))))
		{
			if(!towerSquare.intersects(GameWindowPanel.mobs[shotMob]) && transparentTowerSquare.intersects(GameWindowPanel.mobs[shotMob]))
			{
				drawLine = false; //stop the shooting of tower
			}
			else
			{
				drawLine = true; //start the shooting
			}
			
			if(groundID != Data.grass)
			{				
				if(groundID == Data.tower1 && GameStore.tower1TargetStrongestCritters)
				{
					 towerStrongestStrategy();	// Event for Strongest strategy	
					 shooting = false;
				}
				else if(groundID == Data.tower2 && GameStore.tower2TargetStrongestCritters)
				{
					towerStrongestStrategy();
					shooting = false;
				}
				else if(groundID == Data.tower3 && GameStore.tower3TargetStrongestCritters )
				{
					towerStrongestStrategy();
					shooting = false;
				}
				else if(groundID == Data.tower1 && GameStore.tower1TargetWeakestCritters )
				{
					towerWeakestStrategy();		// Event for weakest strategy
				}
				else if(groundID == Data.tower2 && GameStore.tower2TargetWeakestCritters)
				{
					towerWeakestStrategy();
				}
				else if(groundID == Data.tower3 && GameStore.tower3TargetWeakestCritters)
				{
					towerWeakestStrategy();
				}
				else if(groundID == Data.tower1 && !GameStore.tower1TargetStrongestCritters && !GameStore.tower1TargetWeakestCritters)
				{
					shooting = true; 
				}
				else if(groundID == Data.tower2 && !GameStore.tower2TargetStrongestCritters && !GameStore.tower2TargetWeakestCritters)
				{
					shooting = true; 
				}
				else if(groundID == Data.tower3 && !GameStore.tower3TargetStrongestCritters && !GameStore.tower3TargetWeakestCritters)
				{
					shooting = true; 
				}
			}
		}
		else
		{
			shooting = false; //stop shooting
			if(shotMob != -1)
			{
				GameWindowPanel.mobs[shotMob].setOriginalTilesetMob(); // call the function to set the original settings
			}		
		}	
		
		if(!shooting)
		{
			if(shotMob != -1)
			{
				GameWindowPanel.mobs[shotMob].setOriginalTilesetMob(); //mob function of GameWindowPanel.java
			}
			if(groundID == Data.tower1 || groundID == Data.tower2 || groundID == Data.tower3)
			{
				for(int i = 0; i < GameWindowPanel.mobs.length; i++)
				{
					if(GameWindowPanel.mobs[i].inGame)
					{
						if(towerSquare.intersects(GameWindowPanel.mobs[i]))
						{
							
							if(groundID != Data.grass)
							{
								shotMob = i;
								GameWindowPanel.mobs[shotMob].setHasFrozen(false);
								if(groundID == Data.tower1 && GameStore.tower1TargetStrongestCritters)
								{
									towerStrongestStrategy();
								}
								else if(groundID == Data.tower2 && GameStore.tower2TargetStrongestCritters)
								{
									towerStrongestStrategy();
								}
								else if(groundID == Data.tower3 && GameStore.tower3TargetStrongestCritters)
								{
									towerStrongestStrategy();
								}
								else if(groundID == Data.tower1 && GameStore.tower1TargetWeakestCritters)
								{
									towerWeakestStrategy();
								}
								else if(groundID == Data.tower2 && GameStore.tower2TargetWeakestCritters)
								{
									towerWeakestStrategy();
								}
								else if(groundID == Data.tower3 && GameStore.tower3TargetWeakestCritters)
								{
									towerWeakestStrategy();
								}
								else if(groundID == Data.tower1 && !GameStore.tower1TargetStrongestCritters && !GameStore.tower1TargetWeakestCritters)
								{
									shooting = true; //start shooting
								}
								else if(groundID == Data.tower2 && !GameStore.tower2TargetStrongestCritters && !GameStore.tower2TargetWeakestCritters)
								{
									shooting = true;//start shooting
								}
								else if(groundID == Data.tower3 && !GameStore.tower3TargetStrongestCritters && !GameStore.tower3TargetWeakestCritters)
								{
									shooting = true; //start shooting
								}
							}
						}
					}
				}
			}
		}			
		
		if(shooting) //if tower is shooting
		{	
			if(loseFrame >= loseTime)
			{
				if(groundID == Data.tower1)
				{
					GameWindowPanel.mobs[shotMob].loseHealth(tower1RangeOfFire, Data.tower1); //critter is loosing its life by tower1 shooting					
					if(shotMob != 0)
					{
						if(towerSquare.intersects(GameWindowPanel.mobs[shotMob-1]))
						{
							if(tower1RangeOfFire > 1)
							{
								GameWindowPanel.mobs[shotMob-1].loseHealth(tower1RangeOfFire-1, Data.tower1); //reduce the health of critter 
							}
							else
							{
								GameWindowPanel.mobs[shotMob-1].loseHealth(tower1RangeOfFire, Data.tower1); 
							}	
							
							if((shotMob-1) != -1)
							{
								GameWindowPanel.mobs[shotMob-1].setOriginalTilesetMob(); //call the mobs method of GameWindowPanel.java
							}
						}
					}
					if(towerSquare.intersects(GameWindowPanel.mobs[shotMob+1]))
					{
						if(tower1RangeOfFire > 1)
						{
							GameWindowPanel.mobs[shotMob+1].loseHealth(tower1RangeOfFire-1, Data.tower1); //reduce the health of critter
						}
						else
						{
							GameWindowPanel.mobs[shotMob+1].loseHealth(tower1RangeOfFire, Data.tower1); //reduce the health of critter
						}
						
						if((shotMob+1) != -1)
						{
							GameWindowPanel.mobs[shotMob+1].setOriginalTilesetMob();  //call the mobs method of GameWindowPanel.java
						}
					}
					loseFrame = 0; 
				}
				else if(groundID == Data.tower2)
				{			
					if(!GameWindowPanel.mobs[shotMob].getHasFrozen() && !GameWindowPanel.mobs[shotMob].getFreeze())
					{
						GameWindowPanel.mobs[shotMob].setHasFrozen(true); //start the shooting of frozen tower
						GameWindowPanel.mobs[shotMob].setFreeze(); //freeze the critter
						Timer timer = new Timer(); 
						try
						{
							timer.schedule(new TimerTask() 
							{
								  @Override
								  public void run() 
								  {
									  if(shotMob != -1)
									  {
										  GameWindowPanel.mobs[shotMob].setHasFrozen(false); //stop the freezing effect of tower
									  }								  
								  }
							}, 1000);
						}
						catch(Exception e)
						{
							
						}						
					}		
										
					GameWindowPanel.mobs[shotMob].loseHealth(tower2RangeOfFire, Data.tower2); //critter is loosing its life by tower2 shooting
					
					loseFrame = 0; 
				}else if(groundID == Data.tower3)
				{												
					GameWindowPanel.mobs[shotMob].loseHealth(tower3RangeOfFire, Data.tower3); //critter is loosing its life tower3 shooting
					loseFrame = 0; 
				}
			}
			else
			{
				loseFrame++;
			}
			try
			{
			if(GameWindowPanel.mobs[shotMob].isDead())
			{				
				shooting = false;
				shotMob = -1;
				
				GameWindowPanel.killed++; //all the critter is finished
				loggerCritters.info("Critter is killed");
				loggerGameGlobal.info("Critter is killed");
				GameWindowPanel.hasWon(); //all the critter is finished and player win the game.
			}
			}
			catch(Exception io) 
			{
				
			}
		}
		else
		{
			if(shotMob != -1)
			{
				GameWindowPanel.mobs[shotMob].setOriginalTilesetMob(); //call the mobs method of GameWindowPanel
			}
		}
	}
	/**
	 * Add the point to the account of user.
	 * @param mobID reward by killing critter
	 */
	public void getMoney(int mobID)
	{
		if(GameWindowPanel.level == 1)
		{
			GameWindowPanel.coinage += Data.deathReward[mobID]; //points are added by killing the critter.
			GameStore.totalScore += Data.deathReward[mobID]; 
		}
		else if(GameWindowPanel.level == 2)
		{
			GameWindowPanel.coinage += Data.deathReward[mobID + 1];
			GameStore.totalScore += Data.deathReward[mobID+1]; 
		}
		else if(GameWindowPanel.level == 3)
		{
			GameWindowPanel.coinage += Data.deathReward[mobID + 2];
			GameStore.totalScore += Data.deathReward[mobID+2]; 
		}
	}
	
	/** fight() method used to used to implement the color of the tile made around 
	 * the towers differently according to their capacities.
	 *  @param the graphics object used to paint the frame.
	 */
	public void fight(Graphics g)
	{
		if(GameWindowPanel.isDebug)
		{
			if(groundID == Data.tower1)
			{
				g.setColor(new Color(0, 255, 0)); //set the range of tower1 on map
				g.drawRect(towerSquare.x, towerSquare.y, towerSquare.width, towerSquare.height);
			}
			else if(groundID == Data.tower2)
			{
				g.setColor(new Color(255, 255, 0)  ); //set the range of tower2 on map
				g.drawRect(towerSquare.x, towerSquare.y, towerSquare.width, towerSquare.height);
				
			}
			else if(groundID == Data.tower3)
			{
				g.setColor(new Color(255, 0, 0)); //set the range of tower3 on map
				g.drawRect(towerSquare.x, towerSquare.y, towerSquare.width, towerSquare.height);
			}
		}		
	
		if(shooting && GameWindowPanel.isGameStarted)
		{
			if(groundID == Data.start)
			{
				g.setColor(new Color(255, 255, 255));
				g.drawLine(x + (width/2), y + (height/2), GameWindowPanel.mobs[shotMob].x + (GameWindowPanel.mobs[shotMob].width/2), GameWindowPanel.mobs[shotMob].y + (GameWindowPanel.mobs[shotMob].height/2));	
				//start shooting when critter come in the range of tower1.
			}
			if(groundID == Data.tower1)
			{
				g.setColor(new Color(0, 255, 0));
				g.drawLine(x + (width/2), y + (height/2), GameWindowPanel.mobs[shotMob].x + (GameWindowPanel.mobs[shotMob].width/2), GameWindowPanel.mobs[shotMob].y + (GameWindowPanel.mobs[shotMob].height/2));	
				//start shooting when critter come in the range of tower1.
				
				if(shootingt1count==0)
				{
					loggerGameGlobal.info("Tower 1 start shooting");
					loggerAllTowers.info("Tower 1 start shooting");
					loggerTower1.info("Tower 1 start shooting");
					loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Tower 1 start shooting");
					shootingt1count++;
				}
			}
			else if(groundID == Data.tower2)
			{
				g.setColor(new Color(255, 255, 0));
				g.drawLine(x + (width/2), y + (height/2), GameWindowPanel.mobs[shotMob].x + (GameWindowPanel.mobs[shotMob].width/2), GameWindowPanel.mobs[shotMob].y + (GameWindowPanel.mobs[shotMob].height/2));
				//start shooting when critter come in the range of tower2.
				if(shootingt2count==0)
				{
					loggerGameGlobal.info("Tower 2 start shooting");
					loggerAllTowers.info("Tower 2 start shooting");
					loggerTower2.info("Tower 2 start shooting");
					loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Tower 2 start shooting");
					shootingt2count++;
				}
			}
			else if(groundID == Data.tower3)
			{
				if(drawLine)
				{
					g.setColor(new Color(255, 0, 0));
					g.drawLine(x + (width/2), y + (height/2), GameWindowPanel.mobs[shotMob].x + (GameWindowPanel.mobs[shotMob].width/2), GameWindowPanel.mobs[shotMob].y + (GameWindowPanel.mobs[shotMob].height/2));
					//start shooting when critter come in the range of tower3.
					if(shootingt3count==0)
					{
						loggerGameGlobal.info("Tower 3 start shooting");
						loggerAllTowers.info("Tower 3 start shooting");
						loggerTower3.info("Tower 3 start shooting");
						loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Tower 3 start shooting");
						shootingt3count++;
					}
				}			
			}
		}
	}
}
	