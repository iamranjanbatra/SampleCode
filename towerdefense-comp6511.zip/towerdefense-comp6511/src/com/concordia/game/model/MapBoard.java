package com.concordia.game.model;
import java.awt.Graphics;

import com.concordia.game.view.map.MapWindowPanel;

/**
 *  The MapBoard class provides the dimensions of tiles in grid and also draws the 
 *  grid on the screen.The specified dimensions are used in other classes for creating
 *  the map.
 */
public class MapBoard 
{
	public static int worldWidth;
	public static int worldHeight;
	public int blockSize = 52;
	
	public MapTile[][] block;
	/**
	 * Constructor method to define the game board and basic game specifications
	 */
	public MapBoard()
	{
		define(); //call define function to draw the map.
	}
	
	/**
	 *  Defines the map board blocks
	 */
	public void define()
	{
		block = new MapTile[worldHeight][worldWidth]; //create the object of MapTile.java
		for(int y = 0; y < block.length; y++)
		{
			for(int x = 0; x < block[0].length; x++)
			{
				block[y][x] = new MapTile((MapWindowPanel.myWidth/2) - ((worldWidth * blockSize)/2) + (x * blockSize), y * blockSize, blockSize, blockSize, Data.grass);
				//create block
			}
		}
	}
	
	/**
	 *  Draws the map board blocks
	 *  @param g The graphics variable used to paint on screen
	 */
	public void draw(Graphics g)
	{
		for(int y = 0; y < block.length; y++)
		{
			for(int x = 0; x < block[0].length; x++)
			{
				block[y][x].draw(g);
				//create block according to the definition of MapTile.java
			}
		}				
	}
}
