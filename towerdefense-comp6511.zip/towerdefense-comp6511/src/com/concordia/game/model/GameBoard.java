package com.concordia.game.model;
import java.awt.*;

import org.apache.log4j.Logger;
import com.concordia.game.model.TowerLog;
import com.concordia.game.view.GameWindowPanel;
/**
 *  The GameBoard class provides the dimensions of tiles in grid and also draws the 
 *  grid on the screen.The specified dimensions are used in other classes for creating
 *  the map.
 *
 */
public class GameBoard 
{
	public static int boardWidth;
	public static int boardHeight;
	public int tileSize = 52;
	public GameBoardTile[][] tile;
	
	/** GameBoard() method is used to call the define() function which will 
	 * define all the characteristics to Board on which a user can play
	 */
	public GameBoard()
	{
		define(); //call define to create map.
	}
	
	/** Define() is used to implement an Array of Tiles to form in order 
	 *  of same height and width as per required by the user with our mapping.
	 */
	public void define()
	{
		tile = new GameBoardTile[boardHeight][boardWidth];
		//loop to create the map of user given dimensions.
		for(int y = 0; y < tile.length; y++) 
		{
			for(int x = 0; x < tile[0].length; x++)
			{
				tile[y][x] = new GameBoardTile((GameWindowPanel.myWidth/2) - ((boardWidth * tileSize)/2) + (x * tileSize), y * tileSize, tileSize, tileSize, Data.grass);
				//set the width and height of map
			}
		}
	}
	
	/**   method is used to implement the physic method used 
	 *   in GameBoardTile.java to implement Tower Square
	 */
	public void physic()
	{
		for(int y = 0; y < tile.length; y++)
		{
			for(int x = 0; x < tile[0].length; x++)
			{
				tile[y][x].physic(); //call the physics function of GameBoardTile.java.
			}
		}
	}
	
	/**
	 *  Responsible for drawing the tiles and placing the towers on the tiles, if any.
	 *  @param g the graphics object used to paint the frame.
	 */
	public void draw(Graphics g)
	{
		for(int y = 0; y < tile.length; y++)
		{
			for(int x = 0; x < tile[0].length; x++)
			{
				tile[y][x].draw(g); //call the draw function of GameBoardTile.java
			}
		}
		for(int y = 0; y < tile.length; y++)
		{
			for(int x = 0; x < tile[0].length; x++)
			{
				tile[y][x].fight(g); //call the fight function of GameBoardTile.java
			}
		}
	}
}
