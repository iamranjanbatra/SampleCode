package com.concordia.game.model;
import java.io.*;
import java.util.*;

import com.concordia.game.view.map.MapWindowPanel;

/**
 *  The MapLoad class gets the height and width of grid and then loads the game board.
 */
public class MapLoad 
{
	/**
	 *  Responsible for loading the map board.
	 *  
	 *  @param loadPath Represents the file load path.
	 *  @return map is loaded or not
	 */
	public boolean loadWorld(File loadPath)
	{
		try
		{			
			Scanner loadScanner = new Scanner(loadPath);
			if(loadScanner.hasNext())
			{
				if(MapBoard.worldHeight == 0)
				{
					MapBoard.worldHeight = Integer.parseInt(loadScanner.next()); //get the height of map
				}
				else
				{
					loadScanner.next();
				}			
			}
			if(loadScanner.hasNext())
			{
				if(MapBoard.worldWidth == 0)
				{
					MapBoard.worldWidth = Integer.parseInt(loadScanner.next()); //get the width of map
				}
				else
				{
					loadScanner.next();
				}
			}					
			while(loadScanner.hasNext())
			{		
				for(int y = 0; y < MapBoard.worldHeight; y++)
				{
					for(int x = 0; x < MapBoard.worldWidth; x++)
					{
						MapWindowPanel.room.block[y][x].groundID = Integer.parseInt(loadScanner.next()); //pass the height and width of map.
					}
				}		
				break;
			}
			
			loadScanner.close();
			return true;
		}
		catch(Exception e)
		{			
		    e.printStackTrace();	
		    return false;
		}		
	}
}
