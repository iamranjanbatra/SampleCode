package com.concordia.game.model;
import java.awt.*;

import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import com.concordia.game.model.TowerLog;
import com.concordia.game.designpattern.DecorationLevel1;
import com.concordia.game.designpattern.DecorationLevel2;
import com.concordia.game.designpattern.DecorationLevel3;
import com.concordia.game.designpattern.ILevelDecorator;
import com.concordia.game.designpattern.BasicLevelDecoration;
import com.concordia.game.view.GameWindow;
import com.concordia.game.view.GameWindowPanel;
import com.concordia.game.view.menu.LoadMaps;

/**
 *  The GameStore class provides an editor that implements the store with three towers.
 *  The editor will then be used for select a new tower to place on the map.
 *  The properties of tower will also shown on screen when hover on the tower icon.
 *  It also provides the facilities to sell and buy the tower.
 */
public class GameStore
{
	
	public static int shopWidth = 4;
	public static int buttonSize = 52;
	public static int cellSpace = 2;
	public static int awayFromRoom = 29;
	public static int iconSize = 20;
	public static int iconSpace = 3;
	public static int iconTextY = 15;
	public static int itemIn = 4;
	public static int heldID = 3;
	public static int realID = -1;
	public static int[] buttonID = {Data.tower1, Data.tower2, Data.tower3, Data.trashCan};
	public static int[] buttonPrice = {10, 20, 30, 0};
	public static int tower1SellingPrice = 5;
	public static int tower2SellingPrice = 10;
	public static int tower3SellingPrice = 15;
	public static int tower1CostPrice = buttonPrice[0];
	public static int tower2CostPrice = buttonPrice[1];
	public static int tower3CostPrice = buttonPrice[2];
	public static int totalScore;
	
	public static boolean tower1TargetStrongestCritters = false;
	public static boolean tower2TargetStrongestCritters = false;
	public static boolean tower3TargetStrongestCritters = false;
	
	public static boolean tower1TargetWeakestCritters = false;
	public static boolean tower2TargetWeakestCritters = false;
	public static boolean tower3TargetWeakestCritters = false;
	
	public static int tower1CostToIncreaseRange = 5;
	public static int tower2CostToIncreaseRange = 10;
	public static int tower3CostToIncreaseRange = 15;
	
	public static int tower1CostToIncreaseRateOfFire = 15;
	public static int tower2CostToIncreaseRateOfFire = 20;
	public static int tower3CostToIncreaseRateOfFire = 25;
	static Logger loggerGameGlobal = Logger.getLogger("gameglobal");
	static Logger loggerTower1 = Logger.getLogger("tower1Alone");
	static Logger loggerTower2 = Logger.getLogger("tower2Alone");
	static Logger loggerTower3 = Logger.getLogger("tower3Alone");
	static Logger loggerAllTowers = Logger.getLogger("allTowers");
	static Logger loggerCritters = Logger.getLogger("critters");
	public Rectangle[] button = new Rectangle[shopWidth];
	public Rectangle buttonHealth;
	public Rectangle buttonCoins;

	public static int totalScoreHidden;
	public static String stringGameMessage;
	public static String stringTipToWin;
	
	public static boolean decoratorPattern = true;
	public boolean holdsItem = false;
	
	/**
	 * GameStore constructor that defines the store.
	 */
	public GameStore()
	{
		define(); //call the define method.
	}
	
	/**
	 * Shows the properties of the tower when the mouse pointer is hovered on the tower.  
	 */
	public void hover()
	{
		for(int y = 0; y < GameWindowPanel.room.tile.length; y++)
		{
			for(int x = 0; x < GameWindowPanel.room.tile[0].length; x++)
			{
				if(GameWindowPanel.room.tile[y][x].contains(GameWindowPanel.mse))
				{
					if(GameWindowPanel.room.tile[y][x].groundID == Data.tower1)
					{
						GameWindow.towerName = "Green"; //pass the tower1 name to GameWindow
						GameWindow.towerType = "Green Laser";  //pass the tower1 type to GameWindow
						GameWindow.towerPurchasePrice = String.valueOf(tower1CostPrice);  //pass the tower1 purchase price to GameWindow
						GameWindow.towerSellingPrice = String.valueOf(tower1SellingPrice);  //pass the tower1 selling price to GameWindow
						GameWindow.costToIncreaseRange = String.valueOf(tower1CostToIncreaseRange);
						GameWindow.costToIncreaseRateOfFire = String.valueOf(tower1CostToIncreaseRateOfFire);
						GameWindow.showTowerInspectionWindow(true, x, y, Data.tower1);  //show tower inspection window while hovering on tower1.
					}
					else if(GameWindowPanel.room.tile[y][x].groundID == Data.tower2)
					{
						GameWindow.towerName = "Yellow"; //pass the tower2 name to GameWindow
						GameWindow.towerType = "Yellow Laser";  //pass the tower2 type to GameWindow
						GameWindow.towerPurchasePrice = String.valueOf(tower2CostPrice); //pass the tower2 purchase price to GameWindow
						GameWindow.towerSellingPrice = String.valueOf(tower2SellingPrice); //pass the tower2 selling price to GameWindow
						GameWindow.costToIncreaseRange = String.valueOf(tower2CostToIncreaseRange);
						GameWindow.costToIncreaseRateOfFire = String.valueOf(tower2CostToIncreaseRateOfFire);
						GameWindow.showTowerInspectionWindow(true, x, y, Data.tower2); //show tower inspection window while hovering on tower2.
					}
					else if(GameWindowPanel.room.tile[y][x].groundID == Data.tower3)
					{
						GameWindow.towerName = "Red";  //pass the tower3 name to GameWindow
						GameWindow.towerType = "Red Laser"; //pass the tower3 type to GameWindow
						GameWindow.towerPurchasePrice = String.valueOf(tower3CostPrice);  //pass the tower3 purchase price to GameWindow
						GameWindow.towerSellingPrice = String.valueOf(tower3SellingPrice); //pass the tower3 selling price to GameWindow
						GameWindow.costToIncreaseRange = String.valueOf(tower3CostToIncreaseRange);
						GameWindow.costToIncreaseRateOfFire = String.valueOf(tower3CostToIncreaseRateOfFire);
						GameWindow.showTowerInspectionWindow(true, x, y, Data.tower3); //show tower inspection window while hovering on tower3.
					}			
				}
			}
		}
		for (int i = 0; i < button.length; i++) //loop to set the selected tower on map and edit the selling and purchase price according to it.
		{
			try
			{
				if(button[i].contains(GameWindowPanel.mse))
				{
					if(buttonID[i] == Data.tower1) 
					{
						GameWindow.towerName = "Green";//set tower name
						GameWindow.towerType = "Green Laser"; //set tower type
						GameWindow.towerPurchasePrice = String.valueOf(buttonPrice[i]); //set purchase price of tower
						GameWindow.towerSellingPrice = String.valueOf(tower1SellingPrice);//set the selling price of tower
						GameWindow.costToIncreaseRange = String.valueOf(tower1CostToIncreaseRange); //set the cost to update the tower
						GameWindow.costToIncreaseRateOfFire = String.valueOf(tower1CostToIncreaseRateOfFire); 
						GameWindow.showTowerInspectionWindow(false, 0, 0, 0);// show inspection window of tower1					
					}
					else if(buttonID[i] == Data.tower2)
					{
						GameWindow.towerName = "Yellow"; //set tower name
						GameWindow.towerType = "Yellow Laser"; //set tower type
						GameWindow.towerPurchasePrice = String.valueOf(buttonPrice[i]);//set purchase price of tower
						GameWindow.towerSellingPrice = String.valueOf(tower2SellingPrice);// set selling price of tower
						GameWindow.costToIncreaseRange = String.valueOf(tower2CostToIncreaseRange); //set cost to update the tower
						GameWindow.costToIncreaseRateOfFire = String.valueOf(tower2CostToIncreaseRateOfFire);
						GameWindow.showTowerInspectionWindow(false, 0, 0, 0); //show inspection window of tower2
					}
					else if(buttonID[i] == Data.tower3)
					{
						GameWindow.towerName = "Red";
						GameWindow.towerType = "Red Laser";//set tower type.
						GameWindow.towerPurchasePrice = String.valueOf(buttonPrice[i]);//set price of tower
						GameWindow.towerSellingPrice = String.valueOf(tower3SellingPrice); //set selling price of tower
						GameWindow.costToIncreaseRange = String.valueOf(tower3CostToIncreaseRange);
						GameWindow.costToIncreaseRateOfFire = String.valueOf(tower3CostToIncreaseRateOfFire);
						GameWindow.showTowerInspectionWindow(false, 0, 0, 0);
					}
					else
					{
						GameWindow.hideTowerInspectionWindow();//hide the tower inspection window
					}
				}
			}
			catch(Exception e)
			{
				
			}
			
		}
	}
	
	/**
	 * Responsible for reducing the coinage once the tower is purchased.
	 * @param buttonPrice contains the price of the button
	 * @param realID contains the towerID
	 * @return points
	 */
	public int purchaseTower(int[] buttonPrice, int realID)
	{
		GameWindowPanel.coinage -= buttonPrice[realID]; //reduce the point from user's account while placing particular tower on map.
		//GameStore.totalScore-= buttonPrice[realID];
		return GameWindowPanel.coinage;
	}
	
	/**
	 *  Reads for defining the mouse clicks received from the GameKeyHandle
	 *  @param mouseButton 1=Left Click, 2=Middle Click, 3=Right Click
	 */
	public void click(int mouseButton)
	{
		if(mouseButton == 1)
		{ //left mouse button
			for (int i = 0; i < button.length; i++)
			{
				if(button[i].contains(GameWindowPanel.mse))
				{
					if(buttonID[i] == Data.trashCan){ //Delete item
						holdsItem = false;
					}
					else
					{
						heldID = buttonID[i]; //select tower.
						realID = i;
						holdsItem = true;
					}					
				}
			}
		}
		if(holdsItem)
		{
			if(GameWindowPanel.coinage >= buttonPrice[realID]) //check the required money to place tower on map
			{
				for(int y = 0; y < GameWindowPanel.room.tile.length; y++)
				{
					for(int x = 0; x < GameWindowPanel.room.tile[0].length; x++)
					{
						if(GameWindowPanel.room.tile[y][x].contains(GameWindowPanel.mse))
						{
							if(GameWindowPanel.room.tile[y][x].groundID != Data.road && GameWindowPanel.room.tile[y][x].groundID != Data.end && GameWindowPanel.room.tile[y][x].groundID != Data.start){
								GameWindowPanel.room.tile[y][x].groundID = heldID; //place tower on map.
								purchaseTower(buttonPrice, realID); //change the points in user account
								holdsItem = false;
							}
						}
					}
				}
			}
		}
		else{
			for(int y = 0; y < GameWindowPanel.room.tile.length; y++)
			{
				for(int x = 0; x < GameWindowPanel.room.tile[0].length; x++)
				{
					if(GameWindowPanel.room.tile[y][x].contains(GameWindowPanel.mse))
					{
						if(GameWindowPanel.room.tile[y][x].groundID == Data.tower1)
						{
							GameWindowPanel.room.tile[y][x].groundID = Data.grass;
							GameWindowPanel.coinage = GameWindowPanel.coinage + GameStore.tower1SellingPrice;
							//GameStore.totalScore = GameStore.totalScore + GameStore.tower1SellingPrice;
							//edit the points from user account while selling the tower1
						}
						else if(GameWindowPanel.room.tile[y][x].groundID == Data.tower2)
						{
							GameWindowPanel.room.tile[y][x].groundID = Data.grass;
							GameWindowPanel.coinage = GameWindowPanel.coinage + GameStore.tower2SellingPrice;
							//GameStore.totalScore = GameStore.totalScore + GameStore.tower2SellingPrice;
							//edit the points from user account while selling the tower2
						}
						else if(GameWindowPanel.room.tile[y][x].groundID == Data.tower3)
						{
							GameWindowPanel.room.tile[y][x].groundID = Data.grass;
							GameWindowPanel.coinage = GameWindowPanel.coinage + GameStore.tower3SellingPrice;
							//GameStore.totalScore = GameStore.totalScore + GameStore.tower3SellingPrice;
							//edit the points from user account while selling the tower3
						}
					}
				}
			}
		}
	}
	
	/**
	 * Responsible for increasing the coinage once the tower is sold.
	 * @param sellingPrice represents the selling price of the tower.
	 * @return points to user account
	 */
	public static int sellChosenTower(int sellingPrice)
	{
		GameWindowPanel.coinage = GameWindowPanel.coinage + sellingPrice;
		//GameStore.totalScore = GameStore.totalScore + sellingPrice;
		return GameWindowPanel.coinage; //add the points by selling the particular tower.
	}
	
	/**
	 * Responsible for determining the tower type while selling a tower.
	 * @param x Represents the x coordinate of the tower.
	 * @param y Represents the y coordinate of the tower.
	 * @param towerType Represents the tower type.
	 */
	public static void sellTower(int x, int y, int towerType)
	{
		if(towerType == Data.tower1)
		{
			GameWindowPanel.room.tile[y][x].groundID = Data.grass;
			sellChosenTower(GameStore.tower1SellingPrice); //call the sellchosenTower method to sell the selected tower1
			GameWindow.hideTowerInspectionWindow();
			loggerGameGlobal.info("Tower 1 Sold");
			loggerTower1.info("Tower 1 Sold");
			loggerAllTowers.info("Tower 1 Sold");
			loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Tower 1 Sold");
		}
		else if(towerType == Data.tower2)
		{
			GameWindowPanel.room.tile[y][x].groundID = Data.grass;
			sellChosenTower(GameStore.tower2SellingPrice); //call the sellchosenTower method to sell the selected tower2
			GameWindow.hideTowerInspectionWindow();
			loggerGameGlobal.info("Tower 2 Sold");
			loggerTower2.info("Tower 2 Sold");
			loggerAllTowers.info("Tower 2 Sold");
			loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Tower 2 Sold");
		}
		else if(towerType == Data.tower3)
		{
			GameWindowPanel.room.tile[y][x].groundID = Data.grass;
			sellChosenTower(GameStore.tower3SellingPrice); //call the sellchosenTower method to sell the selected tower3
			GameWindow.hideTowerInspectionWindow();
			loggerGameGlobal.info("Tower 3 Sold");
			loggerTower3.info("Tower 3 Sold");
			loggerAllTowers.info("Tower 3 Sold");
			loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Tower 3 Sold");
		}
	}
	
	/**
	 * Responsible for reducing the coinage once the tower is upgraded.
	 * @param costPrice Represents the cost price of the tower.
	 * @return points in user account
	 */
	public static int upgradeChosenTower(int costPrice)
	{
		GameWindowPanel.coinage = GameWindowPanel.coinage - costPrice;
		GameStore.totalScore = GameStore.totalScore - costPrice;
		return GameWindowPanel.coinage; //reduce the points from user account while purchasing the particular tower.
	}
	
	/**
	 * Responsible for determining the tower type and tower cost price while upgrading a tower.
	 * @param x Represents the x coordinate of the tower.
	 * @param y Represents the y coordinate of the tower.
	 * @param towerType Represents the tower type.
	 * @param upgradeTo Represents the towerID to which the current tower will be updated to.
	 */
	public static void upgradeTower(int x, int y, int towerType, int upgradeTo)
	{
		if(towerType == Data.tower1 && upgradeTo == Data.tower2)
		{
			sellTower(x, y, towerType); //call the method to select the tower
			upgradeChosenTower(tower2CostPrice); //call the method to update the point of user account
			GameWindowPanel.room.tile[y][x].groundID = Data.tower2;
			loggerGameGlobal.info("Tower 1 upgrade to 2(Green to Yellow)");
			loggerAllTowers.info("Tower 1 Upgrade to Tower 2(Yellow)");
			loggerTower1.info("Tower 1 Upgrade to Tower 2(Yellow)");
			loggerTower2.info("Tower 1 Upgrade to Tower 2(Yellow)");
			loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Tower 1 Upgrade to Tower 2(Yellow)");
		}
		else if((towerType == Data.tower1 || towerType == Data.tower2) && upgradeTo == Data.tower3)
		{
			sellTower(x, y, towerType); //call the method to select the tower
			upgradeChosenTower(tower3CostPrice);  //call the method to update the point of user account
			GameWindowPanel.room.tile[y][x].groundID = Data.tower3;
			if(towerType==5)
			{
				loggerGameGlobal.info("Tower 1 upgrade to 3(Green to red)");
				loggerAllTowers.info("Tower 1 upgrade to 3(Green to red)");
				loggerTower1.info("Tower 1 upgrade to 3(Green to red)");
				loggerTower3.info("Tower 1 upgrade to 3(Green to red)");
				loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Tower 1 Upgrade to Tower 3(Green to red)");
			}
			if(towerType==6)
			{
				loggerGameGlobal.info("Tower 2 upgrade to 3(Yellow to red)");
				loggerAllTowers.info("Tower 2 upgrade to 3(Yellow to red)");
				loggerTower1.info("Tower 2 upgrade to 3(Yellow to red)");
				loggerTower3.info("Tower 2 upgrade to 3(Yellow to red)");
				loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Tower 2 upgrade to 3(Yellow to red)");
			}
		}
	}
	/**
	 * method increase the range of tower after upgrading it.
	 * @param x dimension
	 * @param y dimension
	 * @param towerType type of tower
	 */
	public static void increaseRange(int x, int y, int towerType)
	{
		if(towerType == Data.tower1)
		{
			if((GameWindowPanel.coinage - tower1CostToIncreaseRange >= 0))
			{
				GameWindowPanel.coinage = GameWindowPanel.coinage - tower1CostToIncreaseRange; //reduce points from user account
				GameStore.totalScore = GameStore.totalScore - tower1CostToIncreaseRange;
				GameBoardTile.tower1SquareSize += 20;//increase range
				loggerGameGlobal.info("Range of Tower 1 Increased");
				loggerAllTowers.info("Range of Tower 1 Increased");
				loggerTower1.info("Range of Tower 1 Increased");
				loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Range of Tower 1 Increased");
			}			
		}
		else if(towerType == Data.tower2)
		{
			if((GameWindowPanel.coinage - tower2CostToIncreaseRange >= 0))
			{
				GameWindowPanel.coinage = GameWindowPanel.coinage - tower2CostToIncreaseRange; //reduce points from user account
				GameStore.totalScore = GameStore.totalScore - tower2CostToIncreaseRange;
				GameBoardTile.tower2SquareSize += 20; //increase range
				loggerGameGlobal.info("Range of Tower 2 Increased");
				loggerAllTowers.info("Range of Tower 2 Increased");
				loggerTower2.info("Range of Tower 2 Increased");
				loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Range of Tower 2 Increased");
			}
		}
		else if(towerType == Data.tower3)
		{
			if((GameWindowPanel.coinage - tower3CostToIncreaseRange >= 0))
			{
				GameWindowPanel.coinage = GameWindowPanel.coinage - tower3CostToIncreaseRange; //reduce points from user account
				GameStore.totalScore = GameStore.totalScore - tower3CostToIncreaseRange;
				GameBoardTile.tower3SquareSize += 20; //increase range
				loggerGameGlobal.info("Range of Tower 3 Increased");
				loggerAllTowers.info("Range of Tower 3 Increased");
				loggerTower3.info("Range of Tower 3 Increased");
				loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Range of Tower 3 Increased");
			}
		}			
	}
	/**
	 * method increase the range of rate of fire for particular tower.
	 * @param x dimension
	 * @param y dimension
	 * @param towerType type of tower
	 */
	public static void increaseRateOfFire(int x, int y, int towerType)
	{
		if(towerType == Data.tower1)
		{
			if((GameWindowPanel.coinage - tower1CostToIncreaseRateOfFire) >= 0)
			{
				GameWindowPanel.coinage = GameWindowPanel.coinage - tower1CostToIncreaseRateOfFire;
				GameStore.totalScore = GameStore.totalScore- tower1CostToIncreaseRateOfFire;
				GameBoardTile.tower1RangeOfFire += 1;
				loggerGameGlobal.info("Rate of Fire for Tower 1 Increased");
				loggerAllTowers.info("Rate of Fire for Tower 1 Increased");
				loggerTower1.info("Rate of Fire for Tower 1 Increased");
				loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Rate of Fire for Tower 1 Increase");
			}
		}
		else if(towerType == Data.tower2)
		{
			if((GameWindowPanel.coinage - tower2CostToIncreaseRateOfFire) >= 0)
			{
				GameWindowPanel.coinage = GameWindowPanel.coinage - tower2CostToIncreaseRateOfFire;
				GameStore.totalScore = GameStore.totalScore- tower2CostToIncreaseRateOfFire;
				GameBoardTile.tower2RangeOfFire += 1;
				loggerGameGlobal.info("Rate of Fire for Tower 2 Increased");
				loggerAllTowers.info("Rate of Fire for Tower 2 Increased");
				loggerTower2.info("Rate of Fire for Tower 2 Increased");
				loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Rate of Fire for Tower 2 Increase");
			}
		}
		else if(towerType == Data.tower3)
		{
			if((GameWindowPanel.coinage - tower3CostToIncreaseRateOfFire) >= 0){
				GameWindowPanel.coinage = GameWindowPanel.coinage - tower3CostToIncreaseRateOfFire;
				GameStore.totalScore = GameStore.totalScore- tower3CostToIncreaseRateOfFire;
				GameBoardTile.tower3RangeOfFire += 1;
				loggerGameGlobal.info("Rate of Fire for Tower 3 Increased");
				loggerAllTowers.info("Rate of Fire for Tower 3 Increased");
				loggerTower1.info("Rate of Fire for Tower 3 Increased");
				loggerCritters.info("Map: " + LoadMaps.mapString + " Level " + GameWindowPanel.level + "Rate of Fire for Tower 3 Increase");
			}
		}			
	}
	
	/**
	 * Responsible for drawing the icons of health and coins.
	 */
	@SuppressWarnings("static-access")
	public void define()
	{
		try
		{
			for(int i = 0; i < button.length; i++)
			{
				button[i] = new Rectangle((GameWindowPanel.myWidth/2) - ((shopWidth * (buttonSize + cellSpace))/2) + ((buttonSize + cellSpace) * i), (GameWindowPanel.room.tile[GameWindowPanel.room.boardHeight - 1][0].y) + GameWindowPanel.room.tileSize + awayFromRoom, buttonSize, buttonSize);
			}
			buttonHealth = new Rectangle(GameWindowPanel.room.tile[0][0].x - 1, button[0].y, iconSize, iconSize);
			buttonCoins = new Rectangle(GameWindowPanel.room.tile[0][0].x - 1, button[0].y + button[0].height - iconSize, iconSize, iconSize);
		}
		catch(Exception e)
		{
			//e.printStackTrace();
		}	
	}
	/**
	 * Method used to implement decorator pattern for addition of help and tips in the game
	 */
	int count1=0;
	int count2=0;
	int count3=0;
	public void decoratorFunctionality()
	{
		
		if(GameWindowPanel.level ==1)
		{
		ILevelDecorator levelDecorator = new BasicLevelDecoration();
		stringGameMessage = levelDecorator.gameMessage();
		stringTipToWin = levelDecorator.tipToWin();
		if(count1==0)
		{
			loggerGameGlobal.info("Level1 is started");
			loggerCritters.info("Level1 is started\n\n");
			GameBoardTile.shootingt1count=0;
			GameBoardTile.shootingt2count=0;
			GameBoardTile.shootingt3count=0;
			GameCritter.critterMovingCounter=0;
			count1++;
		}
		}
		if(GameWindowPanel.level ==2)
		{
		ILevelDecorator levelDecorator = new BasicLevelDecoration();
		levelDecorator = new DecorationLevel2(levelDecorator);
		stringGameMessage = levelDecorator.gameMessage();
		stringTipToWin = levelDecorator.tipToWin();
		if(count2==0)
		{
			loggerGameGlobal.info("Level2 is started");
			loggerCritters.info("Level2 is started\n\n");
			GameBoardTile.shootingt1count=0;
			GameBoardTile.shootingt2count=0;
			GameBoardTile.shootingt3count=0;
			GameCritter.critterMovingCounter=0;
			count2++;
		}
		
		}
		if(GameWindowPanel.level ==3)
		{
		ILevelDecorator levelDecorator = new BasicLevelDecoration();
		levelDecorator = new DecorationLevel2(levelDecorator);
		levelDecorator = new DecorationLevel3(levelDecorator);
		stringGameMessage = levelDecorator.gameMessage();
		stringTipToWin = levelDecorator.tipToWin();
		if(count3==0)
		{
			loggerGameGlobal.info("Level3 is started");
			loggerCritters.info("Level3 is started\n\n");
			GameBoardTile.shootingt1count=0;
			GameBoardTile.shootingt2count=0;
			GameBoardTile.shootingt3count=0;
			GameCritter.critterMovingCounter=0;
			count3++;
		}
		}
	}	
	/**
	 * Responsible for drawing the store.
	 * @param g The graphics variable used to paint on screen
	 */
	public void draw(Graphics g)
	{	
		try
		{
		for(int i = 0; i < button.length; i++) //loop to draw the selected tower and changes happens to the user account.
		{
			if(button[i].contains(GameWindowPanel.mse))
			{	
				g.setColor(new Color(255, 255, 255, 100));
				g.fillRect(button[i].x, button[i].y, button[i].width, button[i].height);
			}			
			g.drawImage(GameWindowPanel.tileSetRes[0], button[i].x, button[i].y, button[i].width, button[i].height, null);
			g.drawImage(GameWindowPanel.tileSetGround[buttonID[i]], button[i].x + itemIn, button[i].y + itemIn, button[i].width - (itemIn*2), button[i].height - (itemIn*2), null);
			if(buttonPrice[i] > 0) //check whether user have required point or not for purchasing the tower.
			{
				g.setColor(new Color(255, 255, 255));
				g.setFont(new Font("Courier New", Font.BOLD, 14));
				g.drawString("$" + buttonPrice[i] + "", button[i].x + itemIn, button[i].y + itemIn - 10);
			}		
		}

		decoratorFunctionality();
		
		g.drawImage(GameWindowPanel.tileSetRes[1], buttonHealth.x, buttonHealth.y, buttonHealth.width, buttonHealth.height, null);
		g.drawImage(GameWindowPanel.tileSetRes[2], buttonCoins.x, buttonCoins.y, buttonCoins.width, buttonCoins.height, null);
		g.setFont(new Font("Courier_New", Font.BOLD, 14));
		g.setColor(new Color(255, 255, 255));
		g.drawString("Help Message: " + stringGameMessage + "             Tip: " + stringTipToWin,buttonCoins.x + buttonCoins.width + iconSpace, buttonCoins.y + iconTextY+20);
		g.drawString("" + GameWindowPanel.health, buttonHealth.x + buttonHealth.width + iconSpace, buttonHealth.y + iconTextY);
		g.drawString("$" + GameWindowPanel.coinage, buttonCoins.x + buttonCoins.width + iconSpace, buttonCoins.y + iconTextY);
		g.drawString("Level: " + GameWindowPanel.level + "(" + GameWindowPanel.levelString  + ")             Kills to win: " + (GameWindowPanel.killsToWin - GameWindowPanel.killed) + "               Critters to go: " + (GameWindowPanel.maxMobs - GameWindowPanel.mobCounter) + "               Score: " + totalScore, buttonCoins.x + buttonCoins.width - 25, buttonCoins.y + iconTextY + 35);
		
		if(holdsItem)
		{
			g.drawImage(GameWindowPanel.tileSetGround[heldID], GameWindowPanel.mse.x - ((button[0].width - (itemIn*2))/2) + itemIn, GameWindowPanel.mse.y - ((button[0].width - (itemIn*2))/2) + itemIn, button[0].width - (itemIn*2), button[0].height - (itemIn*2), null);
		}
		}
		catch(Exception e)
		{
			
		}
	}
}
