package com.concordia.game.controller;

import javax.swing.JPanel;

import com.concordia.game.view.GameWindowPanel;

/**
 * This class is used to create a singleton design pattern to create an instance
 *  which is going to be used through-out the schema as game controller.
 */
public class GameController 
{
/**	Global Point of Access of instance to be used. 
 */
	public static GameController gameController;
	/**
	 * Private constructor so that we cannot make another instance of this class
	 */
	private GameController()
	{
		
	}
	/**
	 * Run the iteration of critters and check weather the critter is killed or not.
	 * also call the function which is responsible for starting and implementing critter
	 * waves.
	 * 
	 * @param parentWindow the map having road for critters and ground for tower placement.
	 */
	public void RunIteration(GameWindowPanel parentWindow)
	{
		if(!GameWindowPanel.isFirst && GameWindowPanel.health > 0 && !GameWindowPanel.isWin && GameWindowPanel.isGameStarted)
		{				
			GameWindowPanel.room.physic();//call the physics to implement the critter waves.
			
			if(GameWindowPanel.isGameStarted)
			{
				GameWindowPanel.mobSpawner(); //call the mobSpawner method to start critter wave. 
				
				for(int i = 0; i < GameWindowPanel.mobs.length; i++)
				{
					if(GameWindowPanel.mobs[i].inGame)
					{
						GameWindowPanel.mobs[i].physic(); //first level of game.
					}
				}   				 
			}
		}		
	}
	
	/**
	 * Creation of instance if not previously created or exists
	 */
	public static GameController getInstance()
	{
		if(gameController==null)
		{
			gameController = new GameController(); //create the instance of GameController
		}
		return gameController; //return the instance
	}
}
