package com.concordia.game.view;
import java.awt.*;
import java.awt.image.CropImageFilter;
import java.awt.image.FilteredImageSource;
import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import com.concordia.game.controller.GameController;
import com.concordia.game.designpattern.GameLevelFactory;
import com.concordia.game.model.*;

import javax.swing.*;

import org.apache.log4j.Logger;

import com.concordia.game.view.event.GameKeyHandle;
import com.concordia.game.view.map.MapWindowPanel;
import com.concordia.game.view.menu.LoadMaps;
import com.concordia.game.view.menu.MainMenu;

/**GameWindowPanel class is the class used to implement the window panel of
 * the game where information regarding the components and functionality is placed 
 */
public class GameWindowPanel extends JPanel implements Runnable
{
	private static final long serialVersionUID = 3173158087251007245L;
	public Thread thread = new Thread(this);
	public static Image[] tileSetGround = new Image[100];
	public static Image[] tileSetRes = new Image[100];
	public static Image[] tiletSetMob = new Image[100];
	public static int myWidth, myHeight;
	public static int coinage = 30, health = 10;
	public static boolean isFirst = true;
	public static boolean isDebug = false;
	public static boolean isDead = false;
	public static boolean isWin = false;
	public static int killed = 0, killsToWin = 0, level = 1, maxLevel = 3;
	public static int winTime = 4000, winFrame = 0;
	public static boolean isGameStarted = false;
	public static boolean showLevelWonDialog = true;
	public static boolean startLevel = true;
	public static int maxMobs = 0;	
	public static int mobCounter = 0;
	public int mobsNotInGame = 0;
	public static String levelString = "";
	static Logger loggerGameGlobal = Logger.getLogger("gameglobal");
	static Logger loggerMap = Logger.getLogger("maplog");
	public static GameCritter[] mobs = new GameCritter[10000];
	public static int savedCoinage=0;
	public static Point mse = new Point(0, 0);
    public static boolean endTime = true;
	public static GameBoard room;
	public static GameLoad save;
	public static GameStore store;
	public static int totalScoreHidden;	
	public static String loadFileName;
	/**
	 * Constructor for GameWindowPanel object with no declarations
	 */
	public GameWindowPanel()
	{
		
	}
	
	/**
	 * GameWindowPanel() constructor used to combine mouse events listener on
	 *  windowpanel
	 * @param frame object of GameWindow
	 */
	
	public GameWindowPanel(GameWindow frame)
	{
		frame.addMouseListener(new GameKeyHandle());
		frame.addMouseMotionListener(new GameKeyHandle());
		thread.start(); //run the thread
	}
	/**
	 * Function to display top 5 scores during the end of the game won or lost 
	 */
	public void top5()
	{
		String top5Scores =" ";
		for(int i = 0; i < (GameWindow.topScores.size() > 5 ? 5 : GameWindow.topScores.size()); i++)
		{
			top5Scores += String.valueOf(i+1) + ")" + String.valueOf(GameWindow.topScores.get(i) + " ");
			if(i == 4)
			{
				break;
			}
		}
		if(endTime)
		{
			JOptionPane.showMessageDialog(GameWindow.frame, "Top 5 scores: " + top5Scores);
			endTime = false;
		}
	}
	/**
	 * Function used to determine if user has won the game by game requirements or lost the battle
	 */
	public static void hasWon()
	{
		if(killed == killsToWin)
		{
			isWin = true;
			//killed = 0;
			//coinage = 0;
			loggerMap.info("Won the Game");
		}
	}
	/**
	 * To define coinage required to attain a particular tower to shoot critters
	 * @return coinage the amount of coinage
	 */
	public int defineCoinage()
	{		
		mobCounter = 0;
		
		GameBoardTile.tower1SquareSize = Data.tower1SquareSize;
		GameBoardTile.tower2SquareSize = Data.tower2SquareSize;
		GameBoardTile.tower3SquareSize = Data.tower3SquareSize;
		
		GameBoardTile.tower1RangeOfFire = Data.tower1RangeOfFire;
		GameBoardTile.tower2RangeOfFire = Data.tower2RangeOfFire;
		GameBoardTile.tower3RangeOfFire = Data.tower3RangeOfFire;
		
		return coinage;
	}
	
	/**
	 * define() used to define window panel of game with their 
	 * specified characteristics
	 */
	public void define()
	{	
		if(level == 1)
		{
			room = new GameBoard();
			save = new GameLoad();
			if(MainMenu.lastSaved)
			{
				loadFileName = "fff";
				save.loadWorld(new File("savedMaps/" + loadFileName));
			}
			else
			{
				save.loadWorld(new File("savedMaps/" + loadFileName));
			}
		}
		
		store = new GameStore();
		
		defineCoinage();

		showLevelWonDialog = true;

		for(int i = 0; i < tileSetGround.length; i++) //create the window inspection for tower.
		{
			tileSetGround[i] = new ImageIcon("resources/tileSetGround.png").getImage();
			tileSetGround[i] = createImage(new FilteredImageSource(tileSetGround[i].getSource(), new CropImageFilter(0, 52*i, 52, 52)));
		}
		
		tileSetRes[0] = new ImageIcon("resources/cell.png").getImage();
		tileSetRes[1] = new ImageIcon("resources/heart.png").getImage();
		tileSetRes[2] = new ImageIcon("resources/coin.png").getImage();
					
		GameLevelFactory glf = new GameLevelFactory(level);
		glf.setLevels(level);
		
		for(int i = 0; i < mobs.length; i++)
		{
			mobs[i] = new GameCritter();
		}
	}
	
	/**
	 * paintComponent() is used to implement the paint components including 
	 * setting color and filling the rectangle.
	 * 
	 * @param g the graphics object used to paint the frame.
	 */
	@SuppressWarnings("static-access")
	public void paintComponent(Graphics g)
	{
		if(isFirst && health > 0) 
		{
			myWidth = getWidth();
			myHeight = getHeight() - 40;
			define(); //call the define method
			isFirst = false;
		}	
		try
		{
			g.setColor(new Color(70, 70, 70));
			g.fillRect(0, 0, getWidth(), getHeight());
			g.setColor(new Color(0, 0, 0));
			g.drawLine(room.tile[0][0].x - 1, 0, room.tile[0][0].x - 1, room.tile[room.boardHeight - 1][0].y + room.tileSize); //Drawing the left line
			g.drawLine(room.tile[0][room.boardWidth - 1].x + room.tileSize, 0, room.tile[0][room.boardWidth - 1].x + room.tileSize, room.tile[room.boardHeight - 1][0].y + room.tileSize); //Drawing the right line
			g.drawLine(room.tile[0][0].x, room.tile[room.boardHeight - 1][0].y + room.tileSize, room.tile[0][room.boardWidth - 1].x + room.tileSize, room.tile[room.boardHeight - 1][0].y + room.tileSize); //Drawing the bottom line
			room.draw(g); //Drawing the room
		}
		catch(Exception e)
		{
		
		}
		
		mobsNotInGame = 0;
		
		for(int i = 0; i < mobs.length; i++)
		{
			if(mobs[i].inGame)
			{
				mobs[i].draw(g);
			}
			else
			{
				mobsNotInGame++;
			}	
			
			if(maxMobs == mobCounter && mobsNotInGame == mobs.length)
			{
				if(showLevelWonDialog)
				{
					showLevelWonDialog = false;
					GameWindow.hideTowerInspectionWindow();
					saveScore(GameStore.totalScore);
					loadTop5Scores();
					top5();
					JOptionPane.showMessageDialog(GameWindow.frame, "Game Over. You Lost.");
					
					loggerMap.info(LoadMaps.mapString + " Lost Game Level " + level );
					loggerGameGlobal.info("Score At End "+ GameStore.totalScore );
					loggerGameGlobal.info(LoadMaps.mapString + " Lost Game Level " + level );
				
					System.exit(0);
				}				
			}
		}
		
		if(health < 1 || GameWindowPanel.coinage < 0) //check whether critter is finished or not.
		{
			if(showLevelWonDialog)
			{
				showLevelWonDialog = false;
				isGameStarted = false;
				GameWindow.hideTowerInspectionWindow();
				saveScore(GameStore.totalScore);
				loadTop5Scores();
				top5();
				JOptionPane.showMessageDialog(GameWindow.frame, "Game Over. You Lost.");	
				loggerMap.info(LoadMaps.mapString + " Lost Game Level " + level);
				loggerGameGlobal.info("Score At End "+ GameStore.totalScore );
				loggerGameGlobal.info(LoadMaps.mapString + " Lost Game Level " + level);	
				System.exit(0);
			}			
		}
		
		if(isWin) //check whether critter is finished or not.
		{			
			if(level == maxLevel)
			{
				if(showLevelWonDialog)
				{
					showLevelWonDialog = false;
					GameWindow.hideTowerInspectionWindow();
					saveScore(GameStore.totalScore);
					loadTop5Scores();
					top5();
					JOptionPane.showMessageDialog(GameWindow.frame, "You won the last level!");
					GameWindow.saveButton.show();
					loggerMap.info(LoadMaps.mapString + " Won Game Level " + level);
					loggerGameGlobal.info(LoadMaps.mapString + " Won Game Level " + level);
					
					System.exit(0);
				
				}
			}
			else
			{
				if(showLevelWonDialog)
				{
					GameWindow.hideTowerInspectionWindow();
					showLevelWonDialog = false;
					isGameStarted = false;
					
					JOptionPane.showMessageDialog(GameWindow.frame, "You won the level!");
					
					loggerMap.info(LoadMaps.mapString + " Won Game Level " + level);	
					loggerGameGlobal.info(LoadMaps.mapString + " Won Game Level " + level);
					
					killed = 0;
					isWin = false;
					level++;
					isDebug = false;
					try
					{
					GameWindow.startButton.show();
					GameWindow.saveButton.show();
					define();	
					}
					catch(Exception e)
					{
						
					}
				}							
			}		
		}		
		store.draw(g); //Drawing the store			
	}	
	
	public static int spawnTime = 800;
	public static int spawnFrame = 0;
	
	/**
	 * Function used to check whether mobs or critters still exist or spawned in the game.
	 */
	public static void mobSpawner()
	{
		if(spawnFrame >= spawnTime)
		{
			for(int i = 0; i < mobs.length; i++)
			{
				if(!mobs[i].inGame)
				{
					if(mobCounter < maxMobs)
					{
						mobs[i].spawnMob(Data.ghostCritter, i);
						mobCounter++;
						break;
					}
				}
			}
			spawnFrame = 0;
		}
		else
		{
			spawnFrame++;
		}
	}
	
	/**
	 * saveScore() method to append the score at the end of the file in which map saved
	 * @param score the score scored by the user
	 */
	public void saveScore(int score)
	{
		try 
		{
			BufferedWriter bw = new BufferedWriter(new FileWriter("savedMaps/" + LoadMaps.mapString, true));
			bw.write(" ");
			bw.write(String.valueOf(score));
			bw.flush();
			bw.close();
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Method implemented to load the scores to the option pane during particular instance 
	 * required
	 */
	public void loadTop5Scores()
	{
		try
		{			
			Scanner loadScanner = new Scanner(GameLoad.loadPath);
			if(loadScanner.hasNext())
			{
				if(GameBoard.boardHeight == 0)
				{
					GameBoard.boardHeight = Integer.parseInt(loadScanner.next()); // get the height of map from user.
				}
				else
				{
					loadScanner.next();
				}			
			}
			if(loadScanner.hasNext())
			{
				if(GameBoard.boardWidth == 0)
				{
					GameBoard.boardWidth = Integer.parseInt(loadScanner.next());  // get the width of map from user.
				}
				else
				{
					loadScanner.next();
				}
			}
						
			while(loadScanner.hasNext())
			{
				for(int y = 0; y < GameBoard.boardHeight; y++)
				{
					for(int x = 0; x < GameBoard.boardWidth; x++)
					{
						loadScanner.next();
					}
				}
				break;
			}
			
			GameWindow.topScores = new ArrayList<Integer>();
			
			while(loadScanner.hasNextInt())
			{				
				GameWindow.topScores.add(Integer.parseInt(loadScanner.next()));				
			}	
			
			Collections.sort(GameWindow.topScores, Collections.reverseOrder());
			
			loadScanner.close();
		}
		catch(Exception e)
		{			
			 //ex.printStackTrace();					
		}	
	}

	/**
	 * run() method is used to implement the thread which will be responsible 
	 * for the execution of complete game where singleton pattern is used to attain that
	 * It's a game loop.
	 */
	public void run()
	{		
		GameController gameController = GameController.getInstance();
				
		while(true)
		{ 
			gameController.RunIteration(this);

			repaint();
			try 
			{
				Thread.sleep(1);
			} 
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
}
