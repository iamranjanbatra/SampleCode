package com.concordia.game.view.menu;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.io.*;
import org.apache.log4j.*;
import org.apache.log4j.Logger;

import com.concordia.game.view.GameWindow;

/**
 *  Responsible for creating a main menu that has the options of either to create a map or load the saved maps.
 *
 */
public class MainMenu extends JFrame 
{

	private static final long serialVersionUID = -3961152667751628917L;
	public static String title = "SOEN 6441 - Tower Defense Main Menu";
	public static Dimension size = new Dimension(350, 200);
	public static MainMenu frame;
	public static JPanel panel;
	public static boolean lastSaved;
	static Logger loggerMainMenu = Logger.getLogger("gameglobal");
	/**
	 * MainMenu defines all the features used in map and set their default values
	 * 
	 */
	public MainMenu()
	{
		setTitle(title);
		setSize(size);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		init(); //call the init method.
	}
	/**
	 * Made the map visible on screen.
	 */
	
	public void init()
	{	
		setVisible(true);	 //made the window visible on screen.
	}
	
	/**
	 * Method for implementing the main game play
	 * @param args
	 */
	public static void main(String args[])
	{
		frame = new MainMenu();  	
		panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		
		GridBagConstraints gbc = new GridBagConstraints();
		
		JLabel mainMenu = new JLabel("Main Menu");		
		
        gbc.fill = GridBagConstraints.CENTER;
        gbc.weightx = 1;
        gbc.gridx = 0;
        gbc.gridy = 0;
        
		panel.add(mainMenu, gbc); //pass the parameters of main menu label.
				
		JButton newMap = new JButton("New Map");
		
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0.5;
        gbc.gridx = 0;
        gbc.gridy = 2;
        
		panel.add(newMap, gbc); //pass the parameters of new map button.
		
		JButton loadMaps = new JButton("Load Maps");
		
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0.5;
        gbc.gridx = 0;
        gbc.gridy = 3;
        
		panel.add(loadMaps, gbc); //pass the parameters of load map button.
			

		frame.add(panel);
		frame.setVisible(true);
		newMap.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    new MapDimension();	   //call the MapDiminsion method
		  }
		});
		
		loadMaps.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    LoadMaps.loadMaps();    //call the loadMaps method 
		  }
		});
		
		 BasicConfigurator.configure();
		 loggerMainMenu.info("Game Open");
	}	
}
