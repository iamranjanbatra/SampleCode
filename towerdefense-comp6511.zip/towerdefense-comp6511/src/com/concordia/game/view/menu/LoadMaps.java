package com.concordia.game.view.menu;
import java.awt.BorderLayout;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import javax.swing.AbstractAction;
import javax.swing.Action;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import org.apache.log4j.Logger;

import com.concordia.game.component.ButtonColumn;
import com.concordia.game.model.GameBoard;
import com.concordia.game.model.MapBoard;
import com.concordia.game.view.GameWindow;
import com.concordia.game.view.GameWindowPanel;
import com.concordia.game.view.map.MapWindow;
import com.concordia.game.view.map.MapWindowPanel;

/**
 *  Responsible for loading the saved maps in a JTable.
 *
 */
public class LoadMaps extends JFrame
{

	private static final long serialVersionUID = 2775369908882264104L;
	public static String title = "SOEN 6441 - Tower Defense Load Maps";
	public static Dimension size = new Dimension(350, 200);
	public static LoadMaps frame;
	public static JPanel panel;
	static Logger loggerGameGlobal = Logger.getLogger("gameglobal");
	static Logger loggerMap = Logger.getLogger("maplog");
	public static String mapString;
	/**
	 *  LoadMaps defines all the features used in map and set their default values
	 */
	public LoadMaps()
	{
		setTitle(title);
		setSize(size);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
		init(); //call the init method.
	}
	/**
	 * Made the map visible on screen.
	 */
	public void init()
	{	
		setVisible(true); //made the map visible on screen
	}
	
	/**
	 *  Loads the saved maps in a JTable.
	 *  @return table the screen which gives option of play and edit saved map.
	 */
	public static JTable loadMaps()
	{
		frame = new LoadMaps();
		Container content = frame.getContentPane();	    
	    File folder = new File("savedMaps");
	    
		File[] listOfFiles = folder.listFiles();	//create the list of saved maps.
		
		final Object rows[][] = new Object[listOfFiles.length][3];
		
		for (int i = 0; i < listOfFiles.length; i++) 
		{			
			rows[i][0] = listOfFiles[i].getName(); //get the name of selected map.
			rows[i][1] = "Play";
			rows[i][2] = "Edit";
		}	
	    
	    Object columns[] = { "File", "Play", "Edit" };
	    JTable table = new JTable(rows, columns);
	    
	    JScrollPane scrollPane = new JScrollPane(table);
	    content.add(scrollPane, BorderLayout.CENTER);	
	    /**
	     * Load the map from saved map and user can start the game on the map.
	     */
	    Action play = new AbstractAction()
	    {
			private static final long serialVersionUID = 1L;
			public void actionPerformed(ActionEvent e)
	        {
	            @SuppressWarnings("unused")
				JTable table = (JTable)e.getSource();
	            int modelRow = Integer.valueOf( e.getActionCommand() );
	            String fileName = (String) rows[modelRow][0];
	            mapString = fileName;
	            loggerGameGlobal.info("Map " + fileName + " Opened for Play");
	            loggerMap.info("Map " + fileName + " Opened for Play");
	            GameWindowPanel.loadFileName = fileName; //load the selected map.
	            setWidthAndHeightPlaymap(new File("savedMaps/" + fileName));
	            GameWindow.drawGameWindow();
	        }			
	    };
	    /**
	     * Load the map from saved map and user can edit the map and save it again the saved folder.
	     */
	    Action edit = new AbstractAction()
	    {
			private static final long serialVersionUID = 1L;
			public void actionPerformed(ActionEvent e)
	        {
	            @SuppressWarnings("unused")
				JTable table = (JTable)e.getSource();
	            int modelRoww = Integer.valueOf( e.getActionCommand());
	            String fileNamee = (String) rows[modelRoww][0];
	            mapString = fileNamee;
	            loggerGameGlobal.info("Map " + fileNamee + " Opened for editing");
	            loggerMap.info("Map " + fileNamee + " Opened for editing");
	            MapWindowPanel.isMapUpdate = true; 
	            MapWindowPanel.loadFileName = fileNamee; //pass the name of map to MapWindowPanel.
	            setWidthAndHeightPlaymap(new File("savedMaps/" + fileNamee));
	            MapWindow.drawMapWindow(); //call the drawMapWindow method.
	        }			
	    };
	    
	    @SuppressWarnings("unused")
		ButtonColumn buttonColumn1 = new ButtonColumn(table, play, 1);
	    @SuppressWarnings("unused")
		ButtonColumn buttonColumn2 = new ButtonColumn(table, edit, 2);		
	    
	    return table;
	}		
	
	/**
	 *  Sets the width and the height of the game board.
	 *  @param filePath Represents the path of the play map in savedMaps directory
	 */
	public static void setWidthAndHeightPlaymap(File filePath)
	{
		Scanner loadScanner;
		try 
		{
			loadScanner = new Scanner(filePath);
			if(loadScanner.hasNext())
			{
				GameBoard.boardHeight = MapBoard.worldHeight = Integer.parseInt(loadScanner.next()); //pass the height of map.
			//	System.out.println("Board Height = " + GameBoard.boardHeight);
			}
			
			if(loadScanner.hasNext())
			{
				GameBoard.boardWidth = MapBoard.worldWidth = Integer.parseInt(loadScanner.next());//pass the width of map.
			//  System.out.println("Board Width = " + GameBoard.boardWidth);
			}
		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}		
	}
}
