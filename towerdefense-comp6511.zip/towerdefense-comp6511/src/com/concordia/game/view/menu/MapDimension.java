package com.concordia.game.view.menu;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.concordia.game.model.Data;
import com.concordia.game.model.MapBoard;
import com.concordia.game.view.map.MapWindow;

/**
 *  This class is responsible for asking map dimensions from the user and create a map based on the entered dimensions.
 */
public class MapDimension extends JFrame
{
	private static final long serialVersionUID = -8230461295906914584L;
	public static String title = "SOEN 6441 - Tower Defense Map Dimension";
	public static Dimension size = new Dimension(350, 200);
	public static MainMenu frame;
	public static JPanel panel;
	private JTextField boardWidth;
	private JTextField boardHeight;
	private JButton okButton;
	/**
	 *  MapDimensions defines all the features used in map and set their default values
	 */
	public MapDimension()
	{
		setTitle(title);
		setSize(size);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		init(); //call the init method
	}
	
	/**
	 * Used to set the board width
	 * @param width represents the board width
	 */
	
	public boolean setBoardWidth(int width)
	{
		boardWidth.setText(String.valueOf(width));
		if(width <= Data.maxBoardWidth) //validate the user given width of map
		{
			return true;  
		}
		return false;
	}
	
	/**
	 * Used to set the board height
	 * @param height represents the board height
	 */
	public boolean setBoardHeight(int height)//validate the user given height of map
	{
		boardHeight.setText(String.valueOf(height));
		if(height <= Data.maxBoardHeight)
		{
			return true;
		}
		return false;
	}
	
	/**
	 *  The editor contains two TextFields
	 *  and button.TextFields get the dimensions from user and button invoke the action.
	 *  Action command invoke the check on dimensions.If the value is true the MapWindow 
	 *  is called otherwise error message is shown on screen.
	 */
	public void init()
	{	
		setVisible(true);
		frame = new MainMenu();  	
		panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		
		GridBagConstraints gbc = new GridBagConstraints();
        
		JLabel boardWidthLabel = new JLabel("Board Width (Max 12 rows)");		
		
        gbc.fill = GridBagConstraints.CENTER;
        gbc.weightx = 1;
        gbc.gridx = 0;
        gbc.gridy = 0;
        
		panel.add(boardWidthLabel, gbc); //pass the parameters of main menu label.
		
        boardWidth = new JTextField();
        
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.gridx = 0;
        gbc.gridy = 1;
        
        panel.add(boardWidth, gbc); //pass the parameters of TextField.
        
        JLabel boardHeightLabel = new JLabel("Board Height (Max 8 rows)");		
		
        gbc.fill = GridBagConstraints.CENTER;
        gbc.weightx = 1;
        gbc.gridx = 0;
        gbc.gridy = 2;
        
		panel.add(boardHeightLabel, gbc);//pass the parameters of Label.
		
        boardHeight = new JTextField();
        
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.gridx = 0;
        gbc.gridy = 3;
        
        panel.add(boardHeight, gbc);  //pass the parameters of TextField.
  
        okButton = new JButton("OK");
        
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 0;
        gbc.gridx = 0;
        gbc.gridy = 4;
        
        panel.add(okButton, gbc);   //pass the parameters of Button.
        frame.add(panel);
        
        okButton.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
			  if(boardWidth.getText() != "" && boardHeight.getText() != "")
			  {
					try
					{					
						int enteredBoardWidth = Integer.parseInt(boardWidth.getText());
						int enteredBoardHeight = Integer.parseInt(boardHeight.getText());
						if(enteredBoardWidth <= Data.maxBoardWidth && enteredBoardHeight <= Data.maxBoardHeight)
						{
							MapBoard.worldWidth = enteredBoardWidth;
							MapBoard.worldHeight = enteredBoardHeight;
							MapWindow.drawMapWindow(); //call the drawMapWindow method
						}
					}
					catch(NumberFormatException ex)
					{
						ex.printStackTrace();
					}			
				}		    	    
		  }
		});
	}	
}
