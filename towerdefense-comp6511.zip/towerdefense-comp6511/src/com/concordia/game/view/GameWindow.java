package com.concordia.game.view;
import javax.swing.*;
import org.apache.log4j.*;


import com.concordia.game.model.Data;
import com.concordia.game.model.GameStore;
import com.concordia.game.model.MapBoard;
import com.concordia.game.model.MapLoad;
import com.concordia.game.model.MapTile;
import com.concordia.game.view.map.MapWindow;
import com.concordia.game.view.map.MapWindowPanel;
import com.concordia.game.view.menu.LoadMaps;
import com.concordia.game.view.menu.MainMenu;
import com.concordia.game.model.*;
import com.sun.glass.events.WindowEvent;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/** 
 * GameWindow class is the class representing the window and its specifications 
 * which is obtained when user wants to play on that and implement all the components 
 * required for the game.
 */
public class GameWindow extends JFrame 
{
	private static final long serialVersionUID = 2169486140692002695L;
	public static String title = "SOEN 6441 - Tower Defense (Developed by Team 10: Vikram, Ranjan, Leila, and Mandeep)";
	public static Dimension size = new Dimension(700, 1000);
	public static String towerName = "";
	public static String towerType = "";
	public static String towerPurchasePrice = "";
	public static String towerSellingPrice = "";
	public static String costToIncreaseRange = "";
	public static String costToIncreaseRateOfFire = "";
	public static Frame frame;
	public static JPanel panel, startButtonPanel;
	public static JButton startButton;
	public static JButton saveButton;
	public static JButton loadButton;
	public static boolean oneTime=true;
	public static int levelNumber=0;
	public static GameWindowPanel screen;
	static Logger loggerGameGlobal = Logger.getLogger("gameglobal");
	static Logger loggerTower1 = Logger.getLogger("tower1Alone");
	static Logger loggerTower2 = Logger.getLogger("tower2Alone");
	static Logger loggerTower3 = Logger.getLogger("tower3Alone");
	static Logger loggerAllTowers = Logger.getLogger("allTowers");
	static Logger loggerMap = Logger.getLogger("maplog");
	public static String mapSaveString="savedMaps/fff";
	public static String mapString;
	public static ArrayList<Integer> topScores;
	public static MapBoard room;
	public static MapLoad loadMap;
	public MapWindowPanel mapWindowPanel;
	public static int towerReference=0;
	/** GameWindow constructor used to implement the window where user can play
	 * the game with windows specifications.
	 */
	public GameWindow()
	{
		setTitle(title);
		setSize(size);
		setResizable(false);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		init();
	}
	/** 
	 * method used to implement window panel consisting of game window 
	 * and the general information of the components and their workings involved 
	 * in game.
	 */
	public void init()
	{		
		screen = new GameWindowPanel(this);
		add(screen);
		setVisible(true); //made the screen visible on screen
	}
	
	/** drawGameWindow() method used to implement the panel involved to create the game window.
	 */
	public static void drawGameWindow()
	{
		frame = new GameWindow();  	
		panel = new JPanel();
		startButtonPanel = new JPanel();
		
		startButton = new JButton("START");
		loadButton = new JButton("LOAD LAST GAME");
		saveButton = new JButton("SAVE");
		
		startButtonPanel.setPreferredSize(new Dimension(40, 40));
		startButtonPanel.add(startButton);
		startButtonPanel.add(saveButton);

		saveButton.hide();
		frame.add(startButtonPanel, BorderLayout.NORTH);
		
		panel.setPreferredSize(new Dimension(200, 400));
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));	
		
		frame.addWindowListener(new java.awt.event.WindowAdapter() 
		{
		    @Override
		    public void windowClosing(java.awt.event.WindowEvent windowEvent) 
		    {	
		    	loggerGameGlobal.info("Game Closed");
		        {
		            System.exit(0);
		        }
		    }
		});
		
		startButton.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
			  GameWindowPanel.isDebug = true;
			  GameWindowPanel.isGameStarted = true;    
			  startButton.hide();
			  loggerGameGlobal.info("Start Game");
			
		  }
		});
		
	saveButton.addActionListener(new ActionListener()
	{
	  public void actionPerformed(ActionEvent e)
	  { 
		 startButton.hide();
		 String fileSaveGame = "fff";
		 saveFileFileWriter(fileSaveGame);
		 frame.dispose();
		 MainMenu.main(new String[]{});
	  }
	});
}	
	
	
	public static void saveFileFileWriter(String fileSaveGame)
	{
		try 
		{				
			FileWriter fileWriter = new FileWriter(new File("savedMaps/" + fileSaveGame)); //save the map in resource.
			fileWriter.write(String.valueOf(MapBoard.worldHeight));//save the height of map.
			fileWriter.write(" ");
			fileWriter.write(String.valueOf(MapBoard.worldWidth));//save the width of map.
			fileWriter.write(System.getProperty("line.separator"));
			for(int i = 0; i < MapBoard.worldHeight; i++)
			{
				for(int j = 0; j < MapBoard.worldWidth; j++)
				{
					
					fileWriter.write(String.valueOf(GameWindowPanel.room.tile[i][j].groundID));
					fileWriter.write(" ");
				}
				fileWriter.write(System.getProperty("line.separator"));
			}			
			
			fileWriter.close();	
		
		} 
		catch (Exception e1) 
		{
			//e1.printStackTrace();
		}
	}
	/** 
	 * showTowerInspectionWindow() method is used to implement the inspection functions on towers
	 * including their purchase price, selling price, name and type
	 * @param isActiveTower whether the selected tower is selected or active
	 * @param x x-coordinate where the tower is placed
	 * @param y y-coordinate where the tower is placed
	 * @param activeTowerType Tower type of the tower selected or is active
	 */
	public static void showTowerInspectionWindow(boolean isActiveTower, final int x, final int y, final int activeTowerType)
	{
		panel.removeAll();	
		JLabel headingLabel  = new JLabel("Tower Inspection Panel", SwingConstants.CENTER);
		JLabel breakLabel1 = new JLabel(" ");
		JLabel breakLabel2 = new JLabel(" ");
		JLabel towerNameLabel  = new JLabel("Tower Name: " + towerName);
		JLabel towerTypeLabel  = new JLabel("Tower Type: " + towerType);
		JLabel towerPurchaseCostLabel  = new JLabel("Purchase Price: $" + towerPurchasePrice);
		JLabel towerSellingCostLabel  = new JLabel("Selling Price: $" + towerSellingPrice);
		JLabel costToIncreaseRangeLabel  = new JLabel("Cost to increase range: $" + costToIncreaseRange);
		JLabel costToIncreaseRateOfFireLabel  = new JLabel("Cost to increase rate of fire: $" + costToIncreaseRateOfFire);
		
		//JLabel showLog=new JLabel("Show logs");
		
		JButton towerSellingButton = new JButton("Sell this tower");
		JButton upgradeToYelloTower = new JButton("Upgrade to Yello Tower");
		JButton upgradeToRedTower = new JButton("Upgrade to Red Tower");
		JButton increaseRange = new JButton("Increase range");
		JButton increaseRateOfFire = new JButton("Increase rate of fire");
		JButton targetStrongestCritters = new JButton("Target strongest critters");
		JButton targetWeakestCritters = new JButton("Target weakest critters");
		JButton gameLogButton = new JButton("Show Game Log");
		
		JButton showTower1log=new JButton("Show Tower1 log");
		JButton showTower2log=new JButton("Show Tower2 log");
		JButton showTower3log=new JButton("Show Tower3 log");
		JButton showTowerlog=new JButton("Show Tower log");
		JButton showWavelog=new JButton("Show Wave log");
						
		panel.add(headingLabel);
		panel.add(breakLabel1);
		panel.add(towerNameLabel);	
		panel.add(towerTypeLabel);
		panel.add(towerPurchaseCostLabel);
		panel.add(towerSellingCostLabel);
		panel.add(costToIncreaseRangeLabel);
		panel.add(costToIncreaseRateOfFireLabel);
		panel.add(breakLabel2);
		//panel.add(showLog);
		
		if(isActiveTower)
		{
			panel.add(increaseRange);
			panel.add(increaseRateOfFire);
			panel.add(towerSellingButton);	
			panel.add(targetStrongestCritters);	
			panel.add(targetWeakestCritters);	
			
			
			if(activeTowerType == Data.tower1)
			{
				if((GameWindowPanel.coinage + GameStore.tower1SellingPrice - GameStore.tower2CostPrice) >= 0)
				{
					panel.add(upgradeToYelloTower); //upgrade tower1 to tower2.
				}
				
				if((GameWindowPanel.coinage + GameStore.tower1SellingPrice - GameStore.tower3CostPrice) >= 0)
				{
					panel.add(upgradeToRedTower);//upgrade tower1 to tower3.
				}	
				panel.add(showTower1log);
				panel.add(showTowerlog);
				panel.add(gameLogButton);
				panel.add(showWavelog);
			}
			else if(activeTowerType == Data.tower2)
			{
				if((GameWindowPanel.coinage + GameStore.tower2SellingPrice - GameStore.tower3CostPrice) >= 0)
				{
					panel.add(upgradeToRedTower);//upgrade tower2 to tower3
				}		
				panel.add(showTower2log);
				panel.add(showTowerlog);
				panel.add(gameLogButton);
				panel.add(showWavelog);
			}
			else if(activeTowerType == Data.tower3)
			{
				if((GameWindowPanel.coinage + GameStore.tower2SellingPrice - GameStore.tower3CostPrice) >= 0)
				{
					panel.add(upgradeToRedTower);//upgrade tower2 to tower3
				}		
				panel.add(showTower3log);
				panel.add(showTowerlog);
				panel.add(gameLogButton);
				panel.add(showWavelog);
			}
		}
		gameLogButton.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    try 
		    {
		    	towerReference = 4;
				TowerLog.towerLog();
			} 
		    catch (IOException e1) 
		    {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		  }
		});
		showTower3log.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    try 
		    {
		    	towerReference = 3;
				TowerLog.towerLog();
			} 
		    catch (IOException e1) 
		    {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		  }
		});
		showTower2log.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    try 
		    {
		    	towerReference = 2;
				TowerLog.towerLog();
			} 
		    catch (IOException e1) 
		    {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		  }
		});
		showTower1log.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    try 
		    {
		    	towerReference = 1;
				TowerLog.towerLog();
			} 
		    catch (IOException e1) 
		    {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		  }
		});
		showTowerlog.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    try 
		    {
		    	towerReference = 0;
				TowerLog.towerLog();
			} 
		    catch (IOException e1) 
		    {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		  }
		});
		showWavelog.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    try 
		    {
		    	towerReference = 5;
				TowerLog.towerLog();
			} 
		    catch (IOException e1) 
		    {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		  }
		});
		
		/**
		 * Implement ActionListener interface
		 *	sell the tower which is active.
		 */
		towerSellingButton.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    GameStore.sellTower(x, y, activeTowerType);	 //call the sellTower to sell the tower.   
		  }
		});
		/**
		 * Implement ActionListener interface
		 *	upgrade the tower which is active.
		 */
		upgradeToYelloTower.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    GameStore.upgradeTower(x, y, activeTowerType, Data.tower2);	     //call the upgardeTower to upgrade the tower.    
		  }
		});
		/**
		 * Implement ActionListener interface
		 *	upgrade the tower which is active.
		 */
		upgradeToRedTower.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    GameStore.upgradeTower(x, y, activeTowerType, Data.tower3);	//call the upgardeTower to upgrade the tower. 
		  }
		});
		
		increaseRange.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    GameStore.increaseRange(x, y, activeTowerType);	//call the upgardeTower to upgrade the tower.
		  }
		  
		});
		
		increaseRateOfFire.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
		    GameStore.increaseRateOfFire(x, y, activeTowerType);	//call the upgardeTower to upgrade the tower.      
		  }
		});
		
		targetStrongestCritters.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
			if(activeTowerType == Data.tower1)
			{
				GameStore.tower1TargetStrongestCritters = true;
				GameStore.tower1TargetWeakestCritters = false;
			}
			else if(activeTowerType == Data.tower2)
			{
				GameStore.tower2TargetStrongestCritters = true;
				GameStore.tower2TargetWeakestCritters = false;
			}
			else if(activeTowerType == Data.tower3)
			{
				GameStore.tower3TargetStrongestCritters = true;
				GameStore.tower3TargetWeakestCritters = false;
			} 
		  }
		});
		
		targetWeakestCritters.addActionListener(new ActionListener()
		{
		  public void actionPerformed(ActionEvent e)
		  {
			if(activeTowerType == Data.tower1)
			{
				GameStore.tower1TargetWeakestCritters = true;
				GameStore.tower1TargetStrongestCritters = false;
			}
			else if(activeTowerType == Data.tower2)
			{
				GameStore.tower2TargetWeakestCritters = true;
				GameStore.tower2TargetStrongestCritters = false;
			}
			else if(activeTowerType == Data.tower3)
			{
				GameStore.tower3TargetWeakestCritters = true;
				GameStore.tower3TargetStrongestCritters = false;
			} 
		  }
		});
				
		panel.revalidate();
		panel.repaint();	
		
		frame.add(panel, BorderLayout.SOUTH);
		
		String top5Scores = "";
		
		for(int i = 0; i < GameWindow.topScores.size(); i++)
		{
			top5Scores += String.valueOf(i+1) + ")" + String.valueOf(GameWindow.topScores.get(i) + " ");
			if(i == 4)
			{
				break;
			}
		}
		if(oneTime)
		{
			JOptionPane.showMessageDialog(GameWindow.frame, "Top 5 scores: " + top5Scores);
			oneTime = false;
		}
	}
	
	/** hideTowerInspectionWindow() method is used to hide the tower inspection
	 * window
	 */
	public static void hideTowerInspectionWindow()
	{
		try
		{
		panel.removeAll();
		panel.revalidate();
		panel.repaint();
		frame.remove(panel);
		}
		catch(Exception e)
		{
		
		}
	}
}
